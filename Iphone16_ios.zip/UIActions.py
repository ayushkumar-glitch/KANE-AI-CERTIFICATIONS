import uuid
import pyotp
try:
    #  DO NOT REMOVE THIS IMPORT, IT IS REQUIRED FOR THE LOGS TO BE SENT TO SUMO
    import log_utils
except ImportError:
    pass
from datetime import datetime, timezone, timedelta
from pydantic import BaseModel
from appium.webdriver.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.interaction import POINTER_TOUCH
from selenium.webdriver.common.actions.mouse_button import MouseButton
from selenium.webdriver.common.action_chains import ActionChains
from appium.webdriver.extensions.android.nativekey import AndroidKey
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from typing import Dict, Optional, List, Tuple
import json, time, traceback, re, base64, httpx, os, math, random, string, calendar, asyncio, io
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from xml.etree import ElementTree
from lxml import etree
from urllib.parse import parse_qsl, urlencode
from typing import Any, Dict, Mapping, Sequence, Union
import unicodedata
from enum import Enum
from io import BytesIO
from appium.webdriver.common.appiumby import AppiumBy

try:
    import numpy as np
    from PIL import Image, ImageChops
except:
    pass

from concurrent.futures import ThreadPoolExecutor
try:
    from generative import GenerativeFlow
except Exception as e:
    pass

try: 
    from condition import Mathmatic, Assertion, CommonParser
except:
    try:
        from selenium_test_agent.models.condition import Mathmatic, Assertion, CommonParser
    except:
        pass

#################################################################################
# HTTP Request Helpers with httpx and retry mechanism
#################################################################################

# Transient HTTP status codes that should trigger a retry
# 408: Request Timeout, 429: Too Many Requests, 499: Client Closed Request
# 502: Bad Gateway, 503: Service Unavailable, 504: Gateway Timeout
TRANSIENT_HTTP_STATUS_CODES = {408, 429, 499, 502, 503, 504}


class TransientHTTPError(Exception):
    """Exception raised for transient HTTP errors that should be retried."""
    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        self.message = message or f"Transient HTTP error with status code {status_code}"
        super().__init__(self.message)


def _is_transient_http_error(status_code: int) -> bool:
    """Check if the HTTP status code is a transient error that should be retried."""
    return status_code in TRANSIENT_HTTP_STATUS_CODES


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type((
        httpx.ConnectError,
        httpx.RemoteProtocolError,
        httpx.ReadError,
        httpx.ConnectTimeout,
        TransientHTTPError
    )),
    reraise=True
)
def make_http_request_with_retry(method: str, url: str, headers: dict = None, data: str = None, json_data: dict = None, timeout: int = 120) -> httpx.Response:
    """
    Makes HTTP requests using httpx with fresh connections and retry mechanism.
    Uses a fresh connection per request to avoid stale connection issues.

    Retries on:
    - Connection errors (ConnectError, RemoteProtocolError, ReadError, ConnectTimeout)
    - Transient HTTP status codes (499, 502, 503, 504)

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc.)
        url: The URL to make the request to
        headers: Optional headers dict
        data: Optional request body as string (for raw data)
        json_data: Optional request body as dict (for JSON data)
        timeout: Request timeout in seconds (default: 120)

    Returns:
        httpx.Response object
    """
    print(f"[httpx-retry] Making {method} request to {url}")
    with httpx.Client(timeout=timeout, follow_redirects=True) as client:
        response = client.request(method, url, headers=headers, data=data, json=json_data)
        if _is_transient_http_error(response.status_code):
            raise TransientHTTPError(response.status_code, f"Transient HTTP error: {response.status_code} for {method} {url}")
        return response


################# Main Methods to handle operations meta data #########################
# operation meta data file
operation_file_path = 'operations_meta_data.json'
#root_meta_data will be used to store all the meta data including all modules and main flow
root_meta_data = {}
current_active_root = "main_flow"
#operations_meta_data will be used to store the meta data of the current flow,let it be module or main flow
operations_meta_data = {}

smart_variables_cache = None

MAX_WAIT_UNTILTIME = 10
IS_SCROLL_ELEMENT_FOUND = -1
TEST_STATUS = "passed"

def set_test_status(status):
    global TEST_STATUS
    TEST_STATUS = status

def get_test_status():
    global TEST_STATUS
    return TEST_STATUS


IS_KANE_AGENT_MODE = False
def set_kane_agent_mode(is_agent: bool):
    global IS_KANE_AGENT_MODE
    IS_KANE_AGENT_MODE = is_agent
    
def is_kane_agent_mode() -> bool:
    global IS_KANE_AGENT_MODE
    return IS_KANE_AGENT_MODE

def reset_kane_agent_mode():
    global IS_KANE_AGENT_MODE
    IS_KANE_AGENT_MODE = False


################################### Smart Wait Appium #######################################
class SmartWaitAppium:

    # ---------------------------------------------------------
    # CONFIGURABLE PARAMETERS
    # ---------------------------------------------------------
    INITIAL_SLEEP = 0.75                   # buffer before polling loop
    POLL_INTERVAL = 0.5                # interval for retry
    VISUAL_POLL_INTERVAL = 0.5                # interval for polling DOM/screenshot
    VISUAL_REQUIRED_CONSECUTIVE_STABLE_FRAMES = 1       # required stable frames
    VISUAL_CHECK_MAX_WINDOW = 5       # maximum screenshot-stability duration
    SCREENSHOT_DOWNSCALE = (128, 128)     # speed-optimized diff resolution
    PIXEL_DIFF_THRESHOLD = 0.015         # <1.5% changed pixels = stable frame

    # detect privacy/black overlays
    BLACKSCREEN_MEAN_THRESHOLD = 5
    BLACKSCREEN_STD_THRESHOLD = 2

    # dim-background detection factor
    DIM_BRIGHTNESS_FACTOR = 0.80        # current_mean < prev_mean * 0.8
    DIM_CONTRAST_FACTOR = 0.65          # current_std < prev_std * 0.65

    # ---------------------------------------------------------
    # LOADER DEFINITIONS
    # ---------------------------------------------------------
    ANDROID_CLASS_LOADERS = [
        "android.widget.ProgressBar",
        "com.google.android.material.progressindicator.CircularProgressIndicator",
        "com.google.android.material.progressindicator.LinearProgressIndicator",
    ]

    IOS_TYPE_LOADERS = [
        "XCUIElementTypeActivityIndicator",
        "XCUIElementTypeProgress",
    ]

    # ---------------------------------------------------------
    def __init__(self, driver: WebDriver, is_ios: bool, wait_config: dict = {}, logger=None):
        self.driver = driver
        self.logger = logger
        self.is_ios = is_ios
        self.wait_config = wait_config
        self.loader_check_processing_time = wait_config.get("loader_check_processing_time", 0.8)
        self.visual_check_processing_time = wait_config.get("visual_check_processing_time", 0.7)
        self.visual_stability_check_enabled = True if str(self.wait_config.get("visual_stability_check", "false")).lower() == "true" else False
        self.visual_required_consecutive_stable_frames = wait_config.get("visual_required_consecutive_stable_frames", self.VISUAL_REQUIRED_CONSECUTIVE_STABLE_FRAMES)
        
        # update additional params
        if wait_config.get("initial_sleep", 0) and isinstance(wait_config.get("initial_sleep"), (int, float)):
            self.INITIAL_SLEEP = wait_config.get("initial_sleep")
        if wait_config.get("visual_check_max_window", 0) and isinstance(wait_config.get("visual_check_max_window"), (int, float)):
            self.VISUAL_CHECK_MAX_WINDOW = wait_config.get("visual_check_max_window")
        if wait_config.get("pixel_diff_threshold", 0) and isinstance(wait_config.get("pixel_diff_threshold"), (int, float)):
            self.PIXEL_DIFF_THRESHOLD = wait_config.get("pixel_diff_threshold")
            
        # check for agent mode
        if is_kane_agent_mode():
            self.visual_stability_check_enabled = True
            self.visual_required_consecutive_stable_frames = max(self.visual_required_consecutive_stable_frames, 2)
            self.loader_check_processing_time = max(self.loader_check_processing_time/2, 0.4)
            self.visual_check_processing_time = max(self.visual_check_processing_time/2, 0.4)
        
        
        # Explicit user-provided lists for loaders
        self.user_loader_ids = wait_config.get("loader_ids", [])     # e.g., ['my_spinner_id']
        self.user_loader_names = wait_config.get("loader_names", []) # e.g., ['Loading...']
        self.user_loader_classes = wait_config.get("loader_classes", []) # e.g., ['android.widget.ProgressBar']
        
        # precomputed locators for loader detection
        self._android_loader_xpath = None
        self._ios_loader_predicate = None
        self._build_loader_locators()
        

    # ---------------------------------------------------------
    # PUBLIC ENTRYPOINT
    # ---------------------------------------------------------
    def wait_till_screen_loads(self, timeout: float = 20.0) -> bool:
        try:
            start_time = time.time()
            
            initial_sleep = min(timeout, self.INITIAL_SLEEP)
            if initial_sleep > 0:
                time.sleep(initial_sleep) # to allow transitions to complete

            remaining = max(timeout - initial_sleep, 0)
            if remaining <= 0:
                self._log(f"Timeout reached :: Time taken: {time.time() - start_time} seconds")
                return True
            
            # check for visual checks enabled
            restore_settings_dict = self._update_driver_settings(timeout=remaining)
            deadline = time.time() + remaining
            while time.time() < deadline:
                left_time = deadline - time.time()

                # ---- PHASE 1: DOM-based Loader Detection ----
                self._log("Checking for Loader presence...")
                is_present = self._loader_present(timeout=left_time)
                if is_present:
                    self._log(f"Loader detected")
                    if time.time() <= deadline - self.POLL_INTERVAL:
                        self._log(f"retry after {self.POLL_INTERVAL} seconds")
                        time.sleep(self.POLL_INTERVAL)
                        continue
                    else:
                        break

                self._log("No Loader detected")
                
                if not self.visual_stability_check_enabled:
                    self._log(f"Skipping Visual stability check → screen READY :: Time taken: {time.time() - start_time} seconds")
                    self._restore_driver_settings(restore_settings_dict)
                    return True

                # ---- PHASE 2: Screenshot Stability Check ----
                self._log("Starting Visual stability check...")
                left_time = deadline - time.time()
                if self._visual_stability_check(timeout=left_time):
                    self._log(f"Screen READY (visual stable) :: Time taken: {time.time() - start_time} seconds")
                    self._restore_driver_settings(restore_settings_dict)
                    return True
                
                self._log("Screen not yet visually stable")
                
                if time.time() <= deadline - self.POLL_INTERVAL:
                    self._log(f"retry after {self.POLL_INTERVAL} seconds")
                    time.sleep(self.POLL_INTERVAL)
                    continue
                else:
                    break

            self._restore_driver_settings(restore_settings_dict)
            self._log(f"Timeout reached :: Time taken: {time.time() - start_time} seconds")
            return True
        except Exception as e:
            self._log(f"Exiting Smart wait: {traceback.format_exc()}")
            return True

    # ---------------------------------------------------------
    # PHASE 2: VISUAL STABILITY CHECK + DIM-BACKGROUND DETECTION
    # ---------------------------------------------------------
    def _visual_stability_check(self, timeout: float) -> bool:
        """
        Visual stability check based on *number of stable frames*,
        not wall-clock time. Screenshot capture time does NOT affect
        stability logic; the outer wait_till_screen_loads timeout
        guards the overall duration.
        """
        if timeout <= 0:
            return False
    

        # how many iterations to try in this visual phase
        total_time = min(timeout, self.VISUAL_CHECK_MAX_WINDOW)
        estimated_two_frames = (2 * self.visual_check_processing_time) + self.VISUAL_POLL_INTERVAL
        if total_time < estimated_two_frames:
            self._log(
                f"Not enough time for visual check "
                f"(budget={total_time:.3f}s, need≈{estimated_two_frames:.3f}s) → skipping"
            )
            return False
        
        # how many consecutive stable frames we need
        required_stable_frames = self.visual_required_consecutive_stable_frames
        if required_stable_frames < 1:
            self._log("Not enough time to capture frames → skipping")
            return False

        last_img = None
        stable_frames = 0
        end_time = time.time() + total_time
        while time.time() < end_time:
            img = self._take_downscaled_grayscale()

            # privacy / black-screen check
            if self._is_screenshot_blocked(img):
                self._log("Screenshot blocked → skip visual check and treat as ready")
                return True

            # first frame is just baseline
            if last_img is None:
                last_img = img
                #self._log("First frame captured (baseline)")
                if time.time() <= end_time - self.POLL_INTERVAL:
                    time.sleep(self.VISUAL_POLL_INTERVAL)
                    continue
                else:
                    break

            delta_ratio = self._pixel_diff_ratio(img, last_img)
            self._log(f"pixel-delta={delta_ratio:.4f}")

            if delta_ratio < self.PIXEL_DIFF_THRESHOLD:
                #self._log(f"Frame stable (delta={delta_ratio:.4f})")

                # dim-background detection
                if self._is_dim_background(img, last_img):
                    self._log("Dim overlay detected → reset stable counter")
                    stable_frames = 0
                else:
                    stable_frames += 1
                    self._log(f"Consecutive stable frames: {stable_frames}/{required_stable_frames}")

                    if stable_frames >= required_stable_frames:
                        #self._log("Required number of stable frames reached → screen ready")
                        return True
            else:
                #self._log(f"Frame unstable (delta={delta_ratio:.4f}) → reset stable counter")
                stable_frames = 0

            last_img = img
            if time.time() < end_time - self.VISUAL_POLL_INTERVAL:
                time.sleep(self.VISUAL_POLL_INTERVAL)
                continue
            else:
                break

        #self._log("Visual check window exhausted without enough stable frames → not ready")
        return False


    # ---------------------------------------------------------
    # DIM BACKGROUND DETECTION (screenshot-based)
    # ---------------------------------------------------------
    def _is_dim_background(self, img, last_img):
        prev_mean = last_img.mean()
        prev_std = last_img.std()

        curr_mean = img.mean()
        curr_std = img.std()

        # detect global darkening (dim layer)
        if curr_mean < prev_mean * self.DIM_BRIGHTNESS_FACTOR:
            return True

        # detect contrast reduction caused by overlay
        if curr_std < prev_std * self.DIM_CONTRAST_FACTOR:
            return True

        return False

    # ---------------------------------------------------------
    # UTILS: SCREENSHOT + DIFF
    # ---------------------------------------------------------
    def _take_downscaled_grayscale(self):
        b64 = self.driver.get_screenshot_as_base64()
        raw = base64.b64decode(b64)

        img = Image.open(BytesIO(raw)).convert("L")
        img = img.resize(self.SCREENSHOT_DOWNSCALE, Image.BILINEAR)
        return np.array(img, dtype=np.int16)

    def _pixel_diff_ratio(self, img1, img2):
        diff = np.abs(img1 - img2)
        return diff.sum() / (img1.size * 255)

    def _is_screenshot_blocked(self, arr):
        mean = arr.mean()
        std = arr.std()

        if mean < self.BLACKSCREEN_MEAN_THRESHOLD:
            return True

        if std < self.BLACKSCREEN_STD_THRESHOLD:
            return True

        return False
    
    # ---------------------------------------------------------
    # PRECOMPUTE LOADER LOCATORS
    # ---------------------------------------------------------
    def _build_loader_locators(self):
        """Precompute Android XPath and iOS predicate for loader detection."""

        # ------------ ANDROID: class + keyword-based XPath ------------
        android_conds = []

        # class-based conditions: @class='android.widget.ProgressBar' OR ...
        class_loaders = self.ANDROID_CLASS_LOADERS + self.user_loader_classes
        for cls in class_loaders:
            android_conds.append(f"@class='{cls}'")

        # resource-id / content-desc keyword conditions
        for kw in self.user_loader_ids:
            android_conds.append(f"contains(@resource-id, '{kw}')")
        
        for kw in self.user_loader_names:  
            android_conds.append(f"contains(@content-desc, '{kw}')")

        if android_conds:
            self._android_loader_xpath = f"//*[{ ' or '.join(android_conds) }]"
        else:
            self._android_loader_xpath = None

        # ------------ iOS: type + keyword NSPredicate ------------
        class_loaders = self.IOS_TYPE_LOADERS + self.user_loader_classes
        type_parts = [f"type == '{t}'" for t in class_loaders]

        kw_parts = []
        loader_keywords = self.user_loader_ids + self.user_loader_names
        for kw in loader_keywords:
            safe_kw = kw.replace("'", "\\'")
            kw_parts.append(f"name CONTAINS[c] '{safe_kw}'")
            kw_parts.append(f"label CONTAINS[c] '{safe_kw}'")

        all_parts = type_parts + kw_parts
        if all_parts:
            self._ios_loader_predicate = " OR ".join(all_parts)
        else:
            self._ios_loader_predicate = None

            
    # ---------------------------------------------------------
    # DOM LOADER DETECTION
    # ---------------------------------------------------------
    def _loader_present(self, timeout: float) -> bool:
        try:
            if self.loader_check_processing_time > timeout:
                self._log("Not enough time for loader check.. skipping")
                return False
            if not self.is_ios:
                return self._android_loader()
            return self._ios_loader()
        except:
            return False

    def _android_loader(self) -> bool:
        if not self._android_loader_xpath:
            return False
        return self._has_any_element(AppiumBy.XPATH, self._android_loader_xpath)

    def _ios_loader(self) -> bool:
        if not self._ios_loader_predicate:
            return False

        # single NSPredicate combining types + name/label keywords
        return self._has_any_element(AppiumBy.IOS_PREDICATE, self._ios_loader_predicate)
    
    def _has_any_element(self, by, locator) -> bool:
        """Check if at least one element exists for this locator."""
        try:
            self.driver.find_element(by, locator)
            return True
        except:
            return False

    # ---------------------------------------------------------
    # HELPERS
    # ---------------------------------------------------------
    def _update_driver_settings(self, timeout: float) -> dict:
        self.driver.implicitly_wait(0)
        if self.is_ios:
            return {}
        try:
            restore_settings_dict = {
                "waitForIdleTimeout": int(self.wait_config.get("waitForIdleTimeout", 10000)),
                "waitForSelectorTimeout": int(self.wait_config.get("waitForSelectorTimeout", 10000))
            }
            max_time =int(timeout*1000)
            update_settings_dict = {
                "waitForIdleTimeout": max(int(max_time * 0.8), 1000),
                "waitForSelectorTimeout": 2000
            }
            self.driver.update_settings(update_settings_dict)
            return restore_settings_dict
        except:
            return {
                "waitForIdleTimeout": 10000,
                "waitForSelectorTimeout": 10000
            }
    
    def _restore_driver_settings(self, settings_dict: dict):
        if not settings_dict:
            return
        self.driver.update_settings(settings_dict)

    def _log(self, msg):
        if self.logger and hasattr(self.logger, 'info'):
            try:
                self.logger.info(msg)
            except:
                print(msg)
        else:
            print(msg)

##########################################################################################

######################### Feature Flags Call ##################################
class FeatureFlags:
    DEFAULT_TEXT_TYPING_CONFIG: dict = {
        "android": False,
        "ios": False
    }
    
    DEFAULT_SMART_WAIT_CONFIG: dict = {
        "android": {
            "vision": 3.5,
            "non_vision": 1.5,
            "auto": False
        },
        "ios": {
            "vision": 3.5,
            "non_vision": 1.5,
            "auto": False
        }
    }
    
    def __init__(self, ff_env: str = None):
        feature_flags_env = ff_env or os.getenv("KANEAI_FEATURE_FLAGS", "{}")
        self.text_type_config: dict = self.DEFAULT_TEXT_TYPING_CONFIG
        self.smart_wait_config: dict = {
            "android": self.DEFAULT_SMART_WAIT_CONFIG["android"],
            "ios": self.DEFAULT_SMART_WAIT_CONFIG["ios"]
        }
        try:
            print(f"Loading feature flags: {feature_flags_env}")
            feature_flags = json.loads(feature_flags_env)
            if not feature_flags or not isinstance(feature_flags, dict):
                feature_flags = {}
            self.text_type_config = self._parse_payload_types(feature_flags.get("kaneai_mobile_typing_text"), self.DEFAULT_TEXT_TYPING_CONFIG)
            self.smart_wait_config = {
                "android": self._parse_payload_types(feature_flags.get("kaneai_mobile_smart_wait_android"), self.DEFAULT_SMART_WAIT_CONFIG["android"]),
                "ios": self._parse_payload_types(feature_flags.get("kaneai_mobile_smart_wait_ios"), self.DEFAULT_SMART_WAIT_CONFIG["ios"])
            }
        except:
            print(f"Using default configs for feature flags due to: {traceback.format_exc()}")
        
        print(f"Text typing feature flag config: {self.text_type_config}")
        print(f"Smart wait feature flag config: {self.smart_wait_config}")
        
    
    def _parse_payload_types(self, feature_flag: dict, default_payload: dict) -> dict:
        if not feature_flag or not isinstance(feature_flag, dict):
            return default_payload
        payload = feature_flag.get("payload", default_payload)
        if not isinstance(payload, dict):
            return default_payload
        return payload
    
    
    def is_text_typing_enabled(self, is_ios: bool) -> bool:
        if is_ios:
            return self.text_type_config.get("ios", False)
        
        return self.text_type_config.get("android", False)
    
    def get_smart_wait_config(self, is_ios: bool) -> dict:
        if is_ios:
            return self.smart_wait_config.get("ios")
        return self.smart_wait_config.get("android")
    
#################################################################################


class FailureCondition(Enum):
    FAIL_BUT_CONTINUE_EXECUTING = "Fail but continue executing"
    FAIL_TEST_IMMEDIATELY = "Fail test immediately"
    WARN_BUT_CONTINUE_EXECUTING = "Warn but continue executing"
    NONE = ""

# helper to get operation meta data
def get_operations_meta_data():
    return operations_meta_data

def set_global_variables(variables:list):
    global global_variables
    global_variables = variables
    
def set_user_parameters(parameters:dict):
    global user_parameters
    user_parameters = parameters

# Load operation meta data once using the function
def set_operations_meta_data(file_path: str):
    global operations_meta_data, operation_file_path, root_meta_data
    operation_file_path = file_path
    print("operation_file_path: ", operation_file_path)
    try:
        with open(operation_file_path, 'r') as f:
            root_meta_data = json.load(f) 
    except Exception as e:
        print(f"Error loading operations meta data from {operation_file_path}: {e}")
        root_meta_data = {}
        
    if root_meta_data.get('global_variables'):
        set_global_variables(root_meta_data.get('global_variables'))
    
    if root_meta_data.get('parameters'):
        set_user_parameters(root_meta_data.get('parameters'))
        
    print(f"Operations meta data loaded from: {root_meta_data}")


def override_operations_meta_data(data: dict):
    global operations_meta_data
    operations_meta_data = data

if os.getenv("HYPER") == "true":
    folder_name = os.path.abspath(__file__).split("/")[-2]
    operation_file_path = f"extracted_hye_files/{folder_name}/operations_meta_data.json"

set_operations_meta_data(operation_file_path)
user_variables = root_meta_data.get('variables', {})
user_parameters = root_meta_data.get('parameters', {})
global_variables = root_meta_data.get('global_variables', [])
runtime_variables = {} # used to store runtime operation runtime output variable values
feature_flags = FeatureFlags()
previous_executed_operation = {}

def get_feature_flags() -> FeatureFlags:
    return feature_flags

def init_feature_flags_env(ff_env: str = None):
    global feature_flags
    feature_flags = FeatureFlags(ff_env)

# this function is used to change the operations_meta_data according to the switch_root given , which can be main_flow or module
def reload_metadata_root(switch_root="main_flow"):
    global operations_meta_data
    print(f"Reloading operations meta data for root: {switch_root}")

    global current_active_root
    current_active_root = switch_root

    if switch_root == "main_flow" and root_meta_data.get('global_variables'):
        set_global_variables(root_meta_data.get('global_variables'))
    # Ensure that we reload just the 'main_flow' part of the data
    operations_meta_data = root_meta_data.get(switch_root, {})
    print(f"Updated operations meta data: {operations_meta_data}")

# Update operation meta data
def update_operation_meta_data(operation_index, value):
    if operation_index in operations_meta_data:
        operations_meta_data[operation_index].update(value)
        print(f"Updated operation meta data for index {operation_index}: {operations_meta_data[operation_index]}")
    else:
        print(f"Operation index {operation_index} not found in the metadata")
        

def get_meta_data_value(operation_index) -> dict:
    """
    Safely get operation data from operations_meta_data regardless of whether the key is int or str.
    
    Args:
        operation_index: The operation index (can be int or str)
        
    Returns:
        The operation data dictionary or None if not found
    """
    # Try with string key first
    str_key = str(operation_index)
    if str_key in operations_meta_data:
        return operations_meta_data[str_key]
    
    # Try with integer key
    try:
        int_key = int(operation_index)
        if int_key in operations_meta_data:
            return operations_meta_data[int_key]
    except (ValueError, TypeError):
        pass
    
    print(f"Operation index {operation_index} not found in the metadata")
    return None

def get_previous_executed_operation() -> dict:
    global previous_executed_operation
    if not previous_executed_operation:
        return {}
    return previous_executed_operation
    
def postprocess_operation(operation_index: str):
    curr_operation = get_meta_data_value(operation_index)
    if not curr_operation:
        return
    global previous_executed_operation
    previous_executed_operation = curr_operation
    

def update_global_variable(operation_index: str, value: str, var_name: str=None):
    curr_operation = get_meta_data_value(operation_index)
    is_global_variable = curr_operation.get("is_global_variable", False)
    if not is_global_variable:
        sub_instruction_obj = get_meta_data_value(operation_index).get("sub_instruction_obj", {})
        if isinstance(sub_instruction_obj, str):
            sub_instruction_obj = json.loads(sub_instruction_obj)
        if "global." in sub_instruction_obj.get("operation_dict", {}).get("variable_name", ""):
            var_name = sub_instruction_obj.get("operation_dict", {}).get("variable_name", "").split(".")[1]
        else:
            return
    
    if not value:
        return
    
    is_global_variable_persist = curr_operation.get("is_global_variable_persist", False)
    global_variable_id = curr_operation.get("global_variable_id", None)
    test_variable = TestVariable(global_variables=global_variables)

    if is_global_variable:
        if var_name:
            global_persist_flag = test_variable.update_variable_value_by_name(var_name, str(value))
            if global_persist_flag:
                print(f"Global variable updated with value {value}")
            else:
                print(f"Global variable is not persistent, updating session variable with value {value}")
                test_variable.update_session_variable_value_by_name(var_name, str(value))

        else:
            if is_global_variable_persist:
                test_variable.update_variable_value(global_variable_id, str(value))
                print(f"Global variable updated with value {value}")
            else:
                print(f"Global variable is not persistent, updating session variable with value {value}")
                test_variable.update_session_variable_value_by_id(global_variable_id, str(value))
        
# get all runtime variables
def get_all_runtime_variables() -> dict:
    global runtime_variables
    return runtime_variables


# set operation output variable
def set_operation_output_variable(operation_index: str, var_name: str, var_value: Any):
    if not var_name:
        print(f"No variable name provided to set operation output variable.")
        return
        
    print(f"Operation output: {var_name} = {var_value}")
    global runtime_variables
    runtime_variables[var_name] = var_value
    
    global user_variables
    user_variables[var_name] = var_value
    
    update_global_variable(operation_index, var_value, var_name)
    
    
# set operation user variable
def set_operation_output_user_variable(operation_index: str, var_value: Any):
    curr_operation = get_meta_data_value(operation_index)
    if 'user_variables' in curr_operation:
        if isinstance(curr_operation['user_variables'], str):
            user_vars_list = json.loads(curr_operation['user_variables'])
        else:
            user_vars_list = curr_operation['user_variables']
        
        if not user_vars_list or not isinstance(user_vars_list, list):
            print(f"No user variables to set for this..")
            return
        
        user_var = user_vars_list[0]
        if not isinstance(user_var, dict) or 'name' not in user_var:
            print(f"No user variable found.")
            return
        
        var_name = user_var['name']
        set_operation_output_variable(operation_index, var_name, var_value)
        
        
# set query operation output variable
def set_query_operation_output_variable(operation_index: str, var_value: Any):
    curr_operation = get_meta_data_value(operation_index)
    var_name = curr_operation.get('query_variable_name', None)
    if not var_name:
        var_name = curr_operation.get('variable_name', None)
    
    # apply string to float if eligible
    if var_value and curr_operation.get('string_to_float', False):
        var_value = string_to_float(str(var_value))
        
    set_operation_output_variable(operation_index, var_name, var_value)
    

#######################################################################################



######################### Custom appium driver class ##################################
class CustomAppiumDriver:
    UiAutomator2 = 'uiautomator2'
    System_Popup_Packages = ['com.apple.springboard', 'com.google.android.permissioncontroller', 'com.android.permissioncontroller', 'com.samsung.android.permissioncontroller', 'com.miui.securitycenter', 'com.android.systemui']
    Blocked_Packages_For_Termination = ["com.apple.springboard", "com.sec.android.app.launcher", "com.google.android.apps.nexuslauncher", "com.android.launcher", "com.miui.home", "net.oneplus.launcher", "com.huawei.android.launcher", "com.motorola.launcher3", "com.oppo.launcher", "com.realme.launcher"]

    def __init__(self, driver: WebDriver):
        self.driver = driver
        self.automation_name = str(driver.capabilities.get('automationName', 'Unknown')).lower()
        self.device_os = str(driver.capabilities.get('platformName', 'Unknown')).lower()
        self.appium_driver_window_size = {"width": 0, "height": 0}
        self.max_wait_until_time = MAX_WAIT_UNTILTIME
        self.iOS_device_screen_size = {
            "statusBarSize": {
                "width": 0,
                "height": 0
            },
            "scale": 1,
            "screenSize": {
                "width": 0,
                "height": 0
            }
        }

    # get device os from capabilities
    def get_test_device_os(self) -> str:
        return self.device_os

    # get automation name from capabilities
    def get_automation_name(self) -> str:
        return self.automation_name
    
    def is_ios(self) -> bool:
        return self.automation_name != self.UiAutomator2
    
    # get ios native screen info
    def get_ios_device_screen_size(self) -> Tuple[int, int]:
        if self.automation_name == self.UiAutomator2:
            raise RuntimeError("Method not implemented for Android")
        # iOS → deviceScreenInfo gives screenSize in portrait terms
        self.iOS_device_screen_size = self.driver.execute_script("mobile: deviceScreenInfo")

        size = self.iOS_device_screen_size['screenSize']
        orientation = self.driver.orientation  # 'PORTRAIT' or 'LANDSCAPE'
        initialOrientation = self.driver.capabilities.get('orientation', '')
        
        if orientation.upper() == "LANDSCAPE":
            # swap width/height for landscape
            if initialOrientation.upper() == "LANDSCAPE":
                return size['width'], size['height']
            return size['height'], size['width']
        else:
            if initialOrientation.upper() == "LANDSCAPE":
                return size['height'], size['width']
            return size['width'], size['height']

    # get appium driver screen info
    def get_appium_driver_window_size(self) -> Tuple[int, int]:
        self.appium_driver_window_size = self.driver.get_window_size()
        return self.appium_driver_window_size['width'], self.appium_driver_window_size['height']

    # get screen dimensions: [width, height]
    def get_device_screen_dimensions(self) -> Tuple[int, int]:
        if self.automation_name == self.UiAutomator2:
            return self.get_appium_driver_window_size()
        else:
            return self.get_ios_device_screen_size()
        
    # update driver setting
    def update_driver_settings(self, settings: dict):
        print(f"Updating driver settings: {settings}")
        self.driver.update_settings(settings)
        
    # is keyboard shown
    def is_keyboard_shown(self) -> bool:
        keyboardFindTime = time.time()
        result = self.driver.is_keyboard_shown()
        print(f"Keyboard shown check took {time.time() - keyboardFindTime} seconds")
        return result
    
    # get page source
    def get_page_source(self) -> str:
        return self.driver.page_source.replace('\r\n', '')
    
    # check if webview is loaded or not
    def is_webview_loaded(self, root):
        if self.automation_name != self.UiAutomator2:
            return True
        
        node = root.find(".//android.webkit.WebView")
        if node is None:
            return True
        
        if len(node) > 0:
            return True
        
        return False
    
    # returns page_src with webview loaded timeout
    def get_page_source_with_webview_wait(self):
        if self.automation_name != self.UiAutomator2:
            return self.get_page_source() # Return the page source directly for non-UIAutomator2 drivers
        
        page_src = self.get_page_source()
        is_webview_loaded = False
        retry = 3
        while retry > 0 and not is_webview_loaded:
            root = ElementTree.fromstring(page_src)
            is_webview_loaded = self.is_webview_loaded(root)
            if not is_webview_loaded:
               page_src = self.get_page_source()
            retry -= 1
            
        return page_src

    # get screenshot
    def get_base64_screenshot(self) -> Optional[str]:
        try:
            return self.driver.get_screenshot_as_base64()
        except Exception as e:
            print(f"Error getting screenshot: {e}")
            return None
    
    
    # get current package
    def get_current_package(self) -> Optional[str]:
        if self.automation_name == self.UiAutomator2:
            return self.driver.current_package
        else:
            app_info = self.driver.execute_script("mobile: activeAppInfo")
            return app_info['bundleId']
    
    # check is system popup
    def is_system_popup_package(self, package_name) -> bool:
        if not package_name:
            return False
        return package_name in self.System_Popup_Packages
    
    def is_package_allowed_for_termination(self, package_name: str) -> bool:
        return package_name not in self.Blocked_Packages_For_Termination
    
    # check element is clickable
    def is_element_clickable(self, element: any) -> bool:
        if element is None:
            raise ValueError("Element not found")
        
        # for ios, return true always
        if self.automation_name != self.UiAutomator2:
            return 'true'
        
        is_clickable = element.get_attribute('clickable')
        return is_clickable == 'true'
    
    # get element class
    def get_element_class(self, element: any) -> Optional[str]:
        if not element:
            return None
        
        if self.automation_name != self.UiAutomator2:
            return element.get_attribute('type')
        
        return element.get_attribute('class')
    
    # get element bounds
    def get_element_bounds(self, element: any) -> List[int]:
        elementBoundTime = time.time()
        if element is None:
            raise ValueError("Element not found")
        
        curr_bounds = [0,0,0,0]
        
        # check for iOS
        if self.automation_name != self.UiAutomator2:
            rect = element.rect
            x = rect['x']
            y = rect['y']
            width = rect['width']
            height = rect['height']
            
            curr_bounds = [x, y, x+width, y+height]
        
        else:
            bounds = element.get_attribute('bounds')
            if bounds:
                match = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds)
                if match:
                    x1, y1, x2, y2 = map(int, match.groups())
                    curr_bounds = [x1, y1, x2, y2]
                else:
                    raise ValueError("Bounds coordinates not found")
            else:
                raise ValueError("Element bounds not found")
        
        # clamp bounds to ensure they are within the window size
        scr_width, scr_height = self.get_device_screen_dimensions()
        x1, y1, x2, y2 = curr_bounds
        x1 = max(0, min(x1, scr_width))
        y1 = max(0, min(y1, scr_height))
        x2 = max(0, min(x2, scr_width))
        y2 = max(0, min(y2, scr_height))
        print(f"Element bounds fetched in {time.time() - elementBoundTime} seconds")
        return [x1, y1, x2, y2]


    
    # get scroll screen bounds based on element centre coordinates
    def get_element_scroll_screen_bounds_from_coordinates(self, element_coordinates: list) -> List[int]:
        width, height = self.get_device_screen_dimensions()
        cx = element_coordinates[0]
        cy = element_coordinates[1]

        left_x_distance, right_x_distance = cx, width - cx
        top_y_distance, bottom_y_distance = cy,  height - cy 

        x1, x2, y1, y2 = 0, width, 0, height

        # align screen bounds such that element_coordinates is at the centre
        if left_x_distance < right_x_distance:
            x2 = cx + left_x_distance
        elif left_x_distance > right_x_distance:
            x1 = cx - right_x_distance

        if top_y_distance < bottom_y_distance:
            y2 = cy + top_y_distance
        elif top_y_distance > bottom_y_distance:
            y1 = cy - bottom_y_distance

        return [x1, y1, x2, y2]
    
    
    # get element coordinates from ratio
    def get_element_coordinates_from_ratio(self, element_coordinates_ratio: list) -> list:
        width, height = self.get_device_screen_dimensions()
        element_coordinates = [int(element_coordinates_ratio[0] * width), int(element_coordinates_ratio[1] * height)]
        return element_coordinates
    
    
    # perform close app
    def perform_terminate_app_action(self, package_name: str, kill_timeout_ms: int = 3000, max_attempts: int = 2):
        if not self.is_package_allowed_for_termination(package_name):
            print(f"Skipping termination for blocked package: {package_name}")
            return
        
        current_attempt = 1
        while current_attempt <= max_attempts:
            try:
                self.driver.execute_script("mobile: terminateApp", {"bundleId": package_name, "appId": package_name, "timeout": kill_timeout_ms})
                return
            except:
                if current_attempt >= max_attempts:
                    print(f"Tried Killing the {package_name} but possible that some of its background processes are still running.")
                pass
            current_attempt += 1
    
    
    # driver navigate
    def navigate(self, direction: str):
        direction = direction.lower()
        if direction == 'back':
            self.driver.back()
        elif direction == 'forward':
            self.driver.forward()
        elif direction == 'home':
            self.perform_keyevent("HOME")
        else:
            raise ValueError("Invalid navigation direction: " + direction)
        
    # switch to active element
    def switch_to_active_element(self):
        return self.driver.switch_to.active_element
    
    # perform click
    def perform_click_action(self, element: any, element_class: str|None = "", is_coordinates_used_for_interaction: bool = False, element_coordinates: list = []):
        clickTime = time.time()
        if is_coordinates_used_for_interaction:
            self.driver.tap([(element_coordinates[0], element_coordinates[1])])
            print(f"Click performed using coordinates in {time.time() - clickTime} seconds")
            return
    
        if element is None:
            raise ValueError("Element not found")
            
        x1, y1, x2, y2 = self.get_element_bounds(element)
        w = x2 - x1
        cx = (x2 + x1) // 2
        cy = (y2 + y1) // 2
        
        # set tap coordinates to center by default
        tx = cx
        ty = cy
        
        # check if interactable element class
        non_interactable_classes = ['android.widget.TextView', 'XCUIElementTypeStaticText']
        is_interactable = not (element_class and element_class in non_interactable_classes)
        
        if not is_interactable:
            bounds_scale_ratio = 1
            if self.automation_name != self.UiAutomator2:
                bounds_scale_ratio = 0.36
            
            offset = int(85 * bounds_scale_ratio)
            tx = cx + offset
            
            max_width = int(400 * bounds_scale_ratio)
            if w <= max_width:
                offset = int(50 * bounds_scale_ratio)
                tx = max(cx, x2 - offset)

            if self.automation_name == self.UiAutomator2:
                screen_width, screen_height = self.get_device_screen_dimensions()
                if ty/screen_height > 0.8:
                    ty = y1 + 5 

        self.driver.tap([(tx, ty)])
        print(f"Click performed in {time.time() - clickTime} seconds")
            
            
    # perform native type for android
    def perform_native_type_action(self, input_text: str):
        if self.automation_name != self.UiAutomator2:
            return
        
        actions = ActionBuilder(driver=self.driver)
        action_chain = actions.add_key_input("keyboard")

        # type text until special key is encountered
        str_len = len(input_text)
        i = 0
        text_to_type = ""
        special_chars =  {"#":AndroidKey.POUND,"`":AndroidKey.GRAVE,"\\":AndroidKey.BACKSLASH} 
        actionkey_chars = ["?"]
        while i < str_len:  
            char = input_text[i]
            if char in special_chars or char in actionkey_chars:
                # type accumulated text first
                if text_to_type:
                    self.driver.execute_script("mobile: type", {"text": text_to_type})

                # type special char
                if char in special_chars:
                    self.driver.press_keycode(special_chars[char])
                else:
                    # type action key
                    action_chain.create_key_down(char) # Press key
                    action_chain.create_key_up(char)   # Release key
                    actions.perform()
                    
                text_to_type = ""
            else:
                text_to_type += char
            
            i += 1
            
        if text_to_type:
            self.driver.execute_script("mobile: type", {"text": text_to_type})
        
    
    # perform type action with delay
    def perform_type_action_with_delay(self, input_text: str, delay_ms: int = 0):
        delay_sec = delay_ms / 1000
        
        actions = ActionBuilder(driver=self.driver)
        action_chain = actions.add_key_input("keyboard")

        for char in input_text:
            if self.automation_name == self.UiAutomator2:
                self.perform_native_type_action(char)
            else:
                action_chain.create_key_down(char) # Press key
                action_chain.create_key_up(char)   # Release key
                actions.perform()
                
            time.sleep(delay_sec)
            
        
    # perform type
    def perform_type_action(self, input_text: str, delay_ms: int = 0, element: any = None, element_class: str|None = ""):
        typeTime = time.time()
        if delay_ms > 0:
            self.perform_type_action_with_delay(input_text, delay_ms)
            print(f"Typing with delay of {delay_ms} ms completed in {time.time() - typeTime} seconds")
            return
        
        if self.automation_name == self.UiAutomator2:
            self.perform_native_type_action(input_text)
            print(f"Typing completed in {time.time() - typeTime} seconds")
            return
        
        # editable text classes
        ios_editable_text_classes = ["XCUIElementTypeTextField", "XCUIElementTypeSecureTextField"]
        if element and element_class in ios_editable_text_classes:
            try:
                element.send_keys(input_text)
                print(f"Typing via element send_keys completed in {time.time() - typeTime} seconds")
                return
            except:
                print(f"Typing via element send_keys failed, falling back to char typing.")
                pass
    
        actions = ActionBuilder(driver=self.driver)
        action_chain = actions.add_key_input("keyboard")

        for char in input_text:
            action_chain.create_key_down(char) # Press key
            action_chain.create_key_up(char)   # Release key

        actions.perform()
        print(f"Typing via action chains completed in {time.time() - typeTime} seconds")
    
    
    # perform clear action
    def perform_clear_action(self, element: any, is_coordinates_used_for_interaction: bool = False):
        clearTime = time.time()
        if is_coordinates_used_for_interaction:
            try: 
                active_element = self.switch_to_active_element()
                active_element.clear()
            except:
                if self.automation_name != self.UiAutomator2:
                    self.perform_type_action(input_text="\b"*50, delay_ms=0)
                else:
                    for _ in range(50):
                        self.perform_keyevent(keyevent="DEL")
            print(f"Clear performed using active element in {time.time() - clearTime} seconds")
            return
        
        if element is None:
            raise ValueError("Element not found")
        
        element.clear()
        print(f"Clear performed in {time.time() - clearTime} seconds")
    
    
    # perform selector elements set value action and return true else false
    def perform_selector_element_set_value_action(self, element: any, element_class: str, desired_value: str, action: str) -> bool:
        android_selector_element_classes = ["android.widget.NumberPicker", "android.widget.SeekBar"]
        ios_selector_elements_classes = ["XCUIElementTypePickerWheel", "XCUIElementTypePicker", "XCUIElementTypeDatePicker", "XCUIElementTypeSlider"]
        is_ios = self.automation_name != self.UiAutomator2
        
        # decide if selector elements instead of editable fields
        if not element_class:
            return False
        elif is_ios and (element_class not in ios_selector_elements_classes):
            return False
        elif (not is_ios) and (element_class not in android_selector_element_classes):
            return False
        
        if element is None:
            raise ValueError("Element not found")
        
        if not desired_value:
            raise ValueError("Desired value not found")
            
        if is_ios:
            element.send_keys(desired_value)
        elif element_class == 'android.widget.NumberPicker':
            self.set_number_picker_value(element, desired_value)          
        elif element_class == 'android.widget.SeekBar':
            self.set_seekbar_value(element, desired_value, action)
        
        return True
    
    # perform keyevent
    def perform_keyevent(self, keyevent: str, keycode: int = None):
        keyevent = keyevent.upper()
        if self.automation_name == self.UiAutomator2:
            keycode_map = {
                "HOME": 3,
                "BACK": 4,
                "TAB": 61,
                "SPACE": 62,
                "DEL": 67,
                "RECENT": 187,
                "ENTER": 66
            }
            if keycode is None:
                keycode = keycode_map.get(keyevent)

            if keycode:
                self.driver.press_keycode(keycode)
            else:
                raise ValueError(f"{keyevent} is Unsupported in Android.")
        else:
            # check driver command
            keyevent = {1: "HOME", 2: "SPACE", 3: "ENTER", 4: "DEL", 5: "TAB"}.get(keycode, keyevent)
            
            if keyevent == "BACK":
                self.driver.back()
                return
            
            # check if script command
            keycode_script = {"HOME": "home"}.get(keyevent)
            if keycode_script:
                self.driver.execute_script(f"mobile: pressButton", {"name": keycode_script})
                return
            
            # check if send keys command
            keycode_input = {"TAB": "\t", "SPACE": " ", "DEL": "\b", "ENTER": "\n"}.get(keyevent)
            if keycode_input:
                self.perform_type_action(input_text=keycode_input, delay_ms=0)
                return
            else:
                raise ValueError(f"{keyevent} is Unsupported in iOS.")
    
    
    # perform keyboard actions
    def perform_keyboard_action(self, action: str):
        action = action.upper()
        if self.automation_name == self.UiAutomator2:
            if action == 'HIDE':
                if self.is_keyboard_shown():
                    self.driver.hide_keyboard()
            else:
                raise ValueError("Invalid keyboard action: {}".format(action))
        else:
            raise ValueError("Unsupported operation for iOS")
        
        
    # open notifications
    def open_notifications(self):
        if self.automation_name == self.UiAutomator2:
            self.driver.open_notifications()
            time.sleep(0.5) # Add a delay to allow time for notifications to be visible
        else:
            # for ios: open using scroll from top to bottom
            _, screen_height = self.get_device_screen_dimensions()
            self.perform_scroll_action(0, 0, 0, screen_height-1, "up", 1100)
        
    # hide notifications
    def hide_notifications(self):
        if self.automation_name == self.UiAutomator2:
            self.navigate('back')
        else:
            self.perform_keyevent("HOME")
    
            
    # send app to background
    def send_app_to_background(self, seconds: int):
        self.driver.background_app(seconds)
        
    # activate app
    def activate_app_with_fallback(self, package_name: str):
        self.driver.activate_app(package_name)
        
    # get largest scrollable element
    def get_largest_scrollable_element_bounds(self) -> List[int]:
        """
        Get coordinates of scrollable elements based on direction or device dimensions if none are found.

        Returns:
            List[int]: List containing coordinates [x1, y1, x2, y2].
        """
        
        # get windlow screen dimensions
        window_width, window_height = self.get_device_screen_dimensions()        
        return [0, 0, window_width, window_height]
        
    
    # helper function to perform scroll
    def perform_scroll_action(self, start_x, start_y, end_x, end_y, direction, duration=250, mi_scroll_payload = None):
        """
        Perform a scroll gesture using ActionBuilder (W3C-compliant).
        
        :param start_x: Starting X coordinate
        :param start_y: Starting Y coordinate
        :param end_x: Ending X coordinate
        :param end_y: Ending Y coordinate
        :param duration: Duration of the scroll in milliseconds
        """
        
        # Build the actions sequence
        actions = ActionBuilder(self.driver)
        action_chain = actions.add_pointer_input(POINTER_TOUCH, "touch")

        if mi_scroll_payload is None:
            mi_scroll_payload = {}

        if mi_scroll_payload.get("startX") is not None:
            width, height = self.get_device_screen_dimensions()
            start_x = int(mi_scroll_payload["startX"] * width / mi_scroll_payload["screenWidth"])
            start_y = int(mi_scroll_payload["startY"] * height / mi_scroll_payload["screenHeight"])
            end_x = int(mi_scroll_payload["endX"] * width / mi_scroll_payload["screenWidth"])
            end_y = int(mi_scroll_payload["endY"] * height / mi_scroll_payload["screenHeight"])
            duration = mi_scroll_payload["delay"] * 1000

        # Scroll action sequence
        action_chain.create_pointer_move(duration=0, x=start_x, y=start_y)  # Move to start point
        action_chain.create_pointer_down()                # Press down
        action_chain.create_pointer_move(duration=duration, x=end_x, y=end_y)  # Scroll gesture
        if mi_scroll_payload.get("is_accurate", False):
            # decide the release pixel based on direction
            release_x, release_y = end_x, end_y
            direction = direction.lower()
            if direction == "up":
                release_y += 1
            elif direction == "down":
                release_y -= 1
            elif direction == "left":
                release_x += 1
            elif direction == "right":
                release_x -= 1
            action_chain.create_pointer_move(duration=duration, x=release_x, y=release_y)
            action_chain.create_pointer_up(0)
        else:
            action_chain.create_pointer_up(MouseButton.LEFT)  # Release
        action_chain.create_pause(0.5)      # Pause
        
        # Perform the gesture
        actions.perform()

    # helper function to move number picker
    def set_number_picker_value(self, element: any, desired_value: str):
        if element is None:
            raise ValueError("Element not found")
        
        if not desired_value:
            raise ValueError("Desired value not provided")
        
        child_elements = element.find_elements(By.XPATH, ".//*")
        if not child_elements or len(child_elements) < 2:
            raise ValueError("No child elements found in the number picker")
        
        # to decide cycle completion
        cycle_completed = False
        initial_valid_val: str = ""
        curr_traversed_val: str = ""
        
        # to decide scroll direction
        scroll_direction = -1
        desired_val_int = int(desired_value) if desired_value.isdigit() else None
        set_scroll_direction = desired_val_int is not None
        
        child_height = child_elements[1].size['height']
        max_attempts = 100
        
        while max_attempts > 0 and not cycle_completed:
            curr_traversed_val = ""
            for child in child_elements:
                curr_val = str(child.text)
                if curr_val == desired_value:
                    child.click()
                    return
                curr_traversed_val += f"{curr_val}-"
                
                # decide scroll direction to reach the desired value faster
                try:
                    if set_scroll_direction and curr_val.isdigit():
                        curr_val_int = int(curr_val)
                        if desired_val_int < curr_val_int:
                            scroll_direction = 1
                            
                        # update scroll direction only once
                        set_scroll_direction = False
                except:
                    print("Error in parsing integer value")

            if initial_valid_val != "" and curr_traversed_val == initial_valid_val:
                cycle_completed = True # Cycle completed without finding the desired value, so no need to continue after the current iteration
            elif initial_valid_val == "" and curr_traversed_val != "":
                initial_valid_val = curr_traversed_val
            
            if not cycle_completed:
                action = ActionChains(self.driver)
                action.click_and_hold(element).move_by_offset(0, scroll_direction * child_height).release().perform()
            
            max_attempts -= 1
        
        raise ValueError(f"Desired value '{desired_value}' not found in the number picker")

    # helper function to move seekbar
    def set_seekbar_value(self, element: any, target_value: str, action: str):
        if element is None:
            raise ValueError("Element not found")
        
        if not target_value:
            raise ValueError("Target value not provided")
        
        desired_value = target_value.lower()
        aspect_ratio_tolerance = 0.1
        location = element.location
        seekbar_size = element.size
        
        width = seekbar_size['width']
        height = seekbar_size['height']
        
        if element.get_attribute('scrollable') == 'true':
            scroll_step = -50
            max_attempts = 100
            while max_attempts > 0:
                content_desc = element.get_attribute("content-desc").lower()
                text_value = element.get_attribute("text").lower()
                
                if desired_value in content_desc or desired_value in text_value:
                    break
                action = ActionChains(self.driver)
                action.click_and_hold(element).move_by_offset(0, scroll_step).release().perform()
                max_attempts -= 1
        elif abs(width - height) / max(width, height) < aspect_ratio_tolerance:
            try:
                desired_value = float(desired_value)
            except ValueError:
                raise ValueError("Target value must be a numeric string.")
            min_val, max_val = 0, 12
            angle = 360 * (desired_value - min_val) / (max_val - min_val)
            element.send_keys(angle)
        else:
            try:
                desired_value = float(desired_value)
            except ValueError:
                raise ValueError("Target value must be a numeric string.")
            
            if action.lower() == "scroll_element_percentage":    
                min_val, max_val = 0, 100
                proportion = (desired_value - min_val) / (max_val - min_val)
                target_x = proportion * width

                action = ActionChains(self.driver)
                action.move_to_element_with_offset(element, -width/2, 0).click_and_hold().move_by_offset(target_x, 0).release().perform()
            else:
                element.send_keys(desired_value)


    # dismiss dialog
    def perform_dismiss_dialog_action(self):
        if self.automation_name == self.UiAutomator2:
            self.navigate('back')
        else:
            self.driver.tap([(10, 75)])
    
    def execute_accessibility_scan(self):
        self.driver.execute_script("lambda-accessibility-scan")    
        print("Accessibility scan executed")

    def compare_base64_images(self, base64_img1):

        base64_img2 = self.get_base64_screenshot()

        # Decode base64 strings into PIL images
        img1 = Image.open(io.BytesIO(base64.b64decode(base64_img1)))
        img2 = Image.open(io.BytesIO(base64.b64decode(base64_img2)))

        # Ensure both images are the same size
        if img1.size != img2.size:
            return False

        # Compute the absolute difference between images
        diff = ImageChops.difference(img1, img2)
        
        # Convert the diff image to grayscale and calculate the sum of pixel values
        diff = diff.convert("L")  # Convert to grayscale
        diff_sum = sum(diff.getdata())

        # Define a threshold for the difference
        threshold = 0  # Adjust this value as necessary

        # If the sum of pixel differences is below the threshold, the images are considered similar
        if diff_sum <= threshold:
            return True
        else:
            return False
#######################################################################################



######################### Autohealer class #############################################
class AutoHealer:
    def __init__(self, driver: WebDriver):
        self.driver = CustomAppiumDriver(driver)
        self.automind_url = os.getenv('AUTOMIND_URL', 'https://kaneai-api.lambdatest.com')
        self.username = os.getenv('LT_USERNAME', 'dummy')
        self.accesskey = os.getenv('LT_ACCESS_KEY', 'dummy')
        self.org_id = int(os.getenv('ORG_ID', '0'))
        self.test_id = os.getenv('TEST_ID', '')
        self.commit_id = os.getenv('COMMIT_ID', '')
        self.session_id = driver.session_id

    class AutoHealerPayload(BaseModel):
        code_export_id: str
        username: str
        accesskey: str
        org_id: int
        test_id: str
        commit_id: str
        session_id: str
        current_action: dict

        prev_actions: Optional[List[dict]] = []
        xpath_mapping: Optional[dict] = {}
        tagified_image: Optional[str] = ""
        tags_description: Optional[dict] = {}
        page_source: Optional[str] = ""

        # specific for mobile
        is_mobile: Optional[bool] = False
        device_os: Optional[str] = ""
        untagged_image_base64: Optional[str] = None
        height: Optional[int] = 0
        width: Optional[int] = 0
        use_query_v2: Optional[bool] = False
        version: Optional[str] = "v1"
        # When True, automind runs QWEN coordinate model alongside GPT in /heal/xpaths
        # and may return coordinate-based response instead of xpaths if QWEN wins comparison
        qwen_fallback_enabled: Optional[bool] = False

    # make healer API call
    def make_healer_api_call(self, operation_index: str, api_endpoint: str, api_method: str, skip_page_source: bool = False) -> httpx.Response:
        # generate api url
        url = f'{self.automind_url}/{api_endpoint.lstrip("/")}'

        # generate headers
        headers = {'Content-Type': 'application/json','Authorization' : f"Basic {base64.b64encode(f'{self.username}:{self.accesskey}'.encode()).decode()}"}

        # generate payload
        req_id = uuid.uuid4().hex[:16]
        width, height = self.driver.get_appium_driver_window_size()
        untagged_screenshot = self.driver.get_base64_screenshot() # added after hierarchy to make sure webview is loaded if required
        
        hierarchy = ""
        if not skip_page_source:
            hierarchy = self.driver.get_page_source_with_webview_wait()
    
        payload = self.AutoHealerPayload(
            # required fields
            code_export_id=req_id,
            username=self.username,
            accesskey=self.accesskey,
            org_id=self.org_id,
            test_id=self.test_id,
            commit_id=self.commit_id,
            session_id=self.session_id,

            # optional fields
            prev_actions=[],
            xpath_mapping={},
            tagified_image="",
            tags_description={},

            # operation specific required fields
            is_mobile=True,
            device_os=self.driver.get_test_device_os(),
            width=width,
            height=height,
            page_source=hierarchy,
            untagged_image_base64=untagged_screenshot,
            current_action=operations_meta_data[operation_index],
            use_query_v2=operations_meta_data[operation_index].get('use_query_v2', False),
            version=operations_meta_data[operation_index].get('version', "v1"),
            qwen_fallback_enabled=True
        )

        # make API call
        print(f"Making Healer API call to [{api_method} {url}], reqId: {req_id}, testId: {self.test_id}, commitId: {self.commit_id}")
        start_time = time.time()  # Record the start time
        response = make_http_request_with_retry(api_method, url, headers=headers, json_data=payload.model_dump(), timeout=120)
        end_time = time.time()  # Record the end time
        elapsed_time = end_time - start_time  # Calculate elapsed time
        print(f"Healer Request completed in {elapsed_time:.2f} seconds")  # Log the time taken by request to complete
        return response
    
    # heal xpaths
    # Returns list[str] of xpaths normally, or dict with coordinate data when QWEN model wins
    def get_healed_xpaths(self, operation_index: str) -> dict | list[str]:
        response = self.make_healer_api_call(operation_index, 'v1/heal/xpaths', 'POST')

        # Check if the response is successful
        if response.status_code == 200:
            # Parse JSON response body
            json_data = response.json()

            if 'error' in json_data:
                print(f"get_healed_xpaths :: response error: {json_data['error']}")
                return []

            # When QWEN coordinate model wins comparison, return coordinate data directly
            if json_data.get('is_coordinates_used_for_interaction', False):
                coord_data = {
                    "is_coordinates_used_for_interaction": True,
                    "element_coordinates_ratio": json_data.get("element_coordinates_ratio", []),
                    "element_bounds_ratio": json_data.get("element_bounds_ratio", []),
                    "response_coordinates": json_data.get("response_coordinates", []),
                    "response_bounds": json_data.get("response_bounds", []),
                }
                print(f"get_healed_xpaths :: coordinate response received: {coord_data}")
                return coord_data

            # Extract the 'xpaths' key, Default to an empty list if 'xpaths' is not present
            xpaths = json_data.get('xpaths', [])

            # Ensure xpaths is a list
            if isinstance(xpaths, list):
                print("get_healed_xpaths :: xpaths: ", xpaths)
                return xpaths
            else:
                print("get_healed_xpaths :: returned 'xpaths' is not a list, response: ", json_data)
        else:
            print(f"get_healed_xpaths :: Request failed with status code: {response.status_code}, body: {response.text}")

        return []
    
    # heal vision query
    def get_healed_vision_query(self, operation_index: str):
        response = self.make_healer_api_call(operation_index, 'v1/heal/vision', 'POST')

        # Check if the response is successful
        if response.status_code == 200:
            # Parse JSON response body
            json_data = response.json()

            if 'error' in json_data:
                print(f"get_healed_vision_query :: response error: {json_data['error']}")
                return None

            # Extract the 'vision_query' key, Default to None if 'vision_query' is not present
            query_content = json_data.get('vision_query', None)

            # Ensure query_content is present
            if query_content is not None:
                return query_content
            else:
                print("get_healed_vision_query :: returned 'vision_query' is not valid, response: ", json_data)
        else:
            print(f"get_healed_vision_query :: Request failed with status code: {response.status_code}, body: {response.text}")

        return None
    
    # resolve operation
    def resolve_operation(self, operation_index: str, max_attempts: int = 2):
        for attempt in range(1, max_attempts):
            print(f"resolve_operation ::  Attempt {attempt} of {max_attempts}")
            response = self.make_healer_api_call(operation_index, 'v1/heal/resolve', 'POST')
            
            # Check if the response is successful
            if response.status_code == 200:
                # Parse JSON response body
                json_data = response.json()

                if 'error' in json_data:
                    print(f"resolve_operation :: response error: {json_data['error']}")
                    time.sleep(2)  # wait before retrying
                    continue
                
                print(f"resolve_operation :: resolved operation: {json_data}")
                return json_data
            
            else:
                print(f"resolve_operation :: Request failed with status code: {response.status_code}, body: {response.text}")
                time.sleep(2)  # wait before retrying
            
        print("resolve_operation :: All attempts to resolve operation have failed.")
        return None
    
    
    # resolve coordinates
    def resolve_coordinates(self, operation_index: str):
        response = self.make_healer_api_call(operation_index, 'v1/heal/coordinates', 'POST', True)

        # Check if the response is successful
        if response.status_code == 200:
            # Parse JSON response body
            json_data = response.json()

            if 'error' in json_data:
                print(f"resolve_coordinates :: response error: {json_data['error']}")
                return None
            
            # Extract the 'element_coordinates_ratio' key, Default to None if 'element_coordinates_ratio' is not present
            element_coordinates_ratio = json_data.get('element_coordinates_ratio', None)
            element_bounds_ratio = json_data.get('element_bounds_ratio', None)

            # Ensure query_content is present
            if (element_bounds_ratio is not None) and isinstance(element_bounds_ratio, list):
                return element_coordinates_ratio, element_bounds_ratio
                
            if element_coordinates_ratio is not None:
                return element_coordinates_ratio, element_bounds_ratio
            else:
                print("resolve_coordinates :: returned 'element_coordinates_ratio' is not valid, response: ", json_data)
        
        else:
            print(f"resolve_coordinates :: Request failed with status code: {response.status_code}, body: {response.text}")
        
        return None, None
    
    
class DbQuery:
    def __init__(self, operation_index: str):
        self.automind_url = os.getenv('AUTOMIND_URL', 'https://kaneai-api.lambdatest.com')
        self.username = os.getenv('LT_USERNAME', 'dummy')
        self.accesskey = os.getenv('LT_ACCESS_KEY', 'dummy')
        self.current_action = operations_meta_data[operation_index]
    
    def db_query(self) -> httpx.Response:
        attempt = 1
        max_attempt = 2

        while (max_attempt >= attempt):
            attempt += 1
            db_details = self.current_action.get("db_details", {})
            query = self.current_action.get("db_query_decoded", "")
            db_bytes = query.encode('utf-8')

            encoded = base64.b64encode(db_bytes)
            encoded_query = encoded.decode('utf-8')
            db_details['tunnel_id'] = os.getenv('LT_PROXY_TUNNEL_ID', 0)
            payload = json.dumps({
                "payload": db_details,
                "query": encoded_query
            })

            headers = {'Content-Type': 'application/json', 'Authorization' : f"Basic {base64.b64encode(f'{self.username}:{self.accesskey}'.encode()).decode()}" }


            
            response = make_http_request_with_retry("POST", url=f"{self.automind_url}/db-query", headers=headers, data=payload)
            if response.status_code == 200:
                print(f"DbQuery :: Request completed successfully, response: {response.json()}")
                return response.json()
            else:
                continue
            
        return response
    
class ScrollQuery:
    def __init__(self, target: str, user_data: dict = None):
        if not user_data:
            user_data = {}
        self.automind_url : str = os.getenv('AUTOMIND_URL', user_data.get('automind_url', 'https://kaneai-api.lambdatest.com'))
        self.username: str = os.getenv('LT_USERNAME',user_data.get('username',''))
        self.accesskey: str = os.getenv('LT_ACCESS_KEY',user_data.get('access_key',''))
        self.target : str = target
        self.screenshot_base64 : str = ''
        self.org_id : int = int(os.getenv('ORG_ID', user_data.get('org_id', '0')))
        self.query_number : int = 0
        self.active_query : int = 0
        self.executor = ThreadPoolExecutor(max_workers=5)  # Set number of concurrent requests

    def scroll_query(self, query_num: int = 0):
        self.active_query += 1
        # Submit the task to the executor to run in a separate thread
        self.executor.submit(self.find_element, query_num)

    def find_element(self, query_num: int = 0):
        headers = {'Content-Type': 'application/json', 'Authorization' : f"Basic {base64.b64encode(f'{self.username}:{self.accesskey}'.encode()).decode()}"}
        
        payload = {
            "target": self.target,
            "screenshot": self.screenshot_base64,
            "org_id": self.org_id
        }

        # Use httpx with retry (blocking call)
        response = make_http_request_with_retry("POST", f"{self.automind_url}/scroll-query", headers=headers, json_data=payload, timeout=120)

        if response.status_code == 200:
            response_data = response.json()
            print(f"ScrollQuery :: Request completed successfully, response: {response_data}, query_num: {query_num}")
            if response_data.get("result", "").lower() == "found":
                global IS_SCROLL_ELEMENT_FOUND
                if IS_SCROLL_ELEMENT_FOUND == -1:
                    IS_SCROLL_ELEMENT_FOUND = query_num
                
        self.active_query -= 1
    
    def verify_element_found(self) -> bool:
        headers = {'Content-Type': 'application/json', 'Authorization' : f"Basic {base64.b64encode(f'{self.username}:{self.accesskey}'.encode()).decode()}"}
        
        payload = {
            "target": self.target,
            "screenshot": self.screenshot_base64,
            "org_id": self.org_id
        }

        # Use httpx with retry (blocking call)
        response = make_http_request_with_retry("POST", f"{self.automind_url}/scroll-query", headers=headers, json_data=payload, timeout=120)

        if response.status_code == 200:
            response_data = response.json()
            print(f"ScrollQuery :: Verify Request completed successfully, response: {response_data}")
            if response_data.get("result", "").lower() == "found":
                return True
            
        return False
   
########################################################################################



################################## Helper methods ######################################

def handle_scroll_until_element(driver: CustomAppiumDriver, operation_index: int) -> bool:
    global IS_SCROLL_ELEMENT_FOUND
    sub_instruction_obj = operations_meta_data[operation_index].get('sub_instruction_obj', {})
    if isinstance(sub_instruction_obj, str):
        sub_instruction_obj = json.loads(sub_instruction_obj)
    
    target : str = sub_instruction_obj.get('operation_dict', {}).get('queried_value', '')
    direction : str = sub_instruction_obj.get('operation_dict', {}).get('direction', 'down')

    if not target:
        print("No target specified for scroll_until_element.")
        return
    
    helper_instance = ScrollQuery(target)

    max_scrolls = 20

    width, height = driver.get_appium_driver_window_size()
    start_x = width / 2
    start_y = height / 2
    mi_scroll_payload = {"is_accurate": True}

    while max_scrolls > 0:

        curr_screenshot_base64 = driver.get_base64_screenshot()
        helper_instance.screenshot_base64 = curr_screenshot_base64
        
        if IS_SCROLL_ELEMENT_FOUND != -1:
            break

        helper_instance.scroll_query(helper_instance.query_number)

        if direction.lower() == 'down':
            driver.perform_scroll_action(start_x, start_y, start_x, 1, direction, 500, mi_scroll_payload)
        else:
            driver.perform_scroll_action(start_x, start_y, start_x, start_y + 200, direction, 500, mi_scroll_payload)

            if driver.compare_base64_images(curr_screenshot_base64):
                break

            driver.perform_scroll_action(start_x, start_y, start_x, height - 200, direction, 500, mi_scroll_payload)

        if driver.compare_base64_images(curr_screenshot_base64):
            break

        helper_instance.query_number += 1
        max_scrolls -= 1

    while helper_instance.active_query > 0 and IS_SCROLL_ELEMENT_FOUND == -1:
        time.sleep(0.2)

    if IS_SCROLL_ELEMENT_FOUND != -1:
        extra_scrolls = helper_instance.query_number - IS_SCROLL_ELEMENT_FOUND

        while extra_scrolls > 0:

            if direction.lower() == 'down':
                driver.perform_scroll_action(start_x, start_y - (start_y / 2), start_x, start_y + (start_y / 2), direction, 500, mi_scroll_payload)
            else:
                driver.perform_scroll_action(start_x, start_y, start_x, 0, direction, 500, mi_scroll_payload)

            extra_scrolls -= 1

        helper_instance.screenshot_base64 = driver.get_base64_screenshot()
        is_element_found = helper_instance.verify_element_found()

        if not is_element_found:
            if direction.lower() == 'down':
                driver.perform_scroll_action(start_x, start_y, start_x, 1, direction, 500, mi_scroll_payload)
            else:
                driver.perform_scroll_action(start_x, start_y, start_x, start_y + 200, direction, 500, mi_scroll_payload)
                driver.perform_scroll_action(start_x, start_y, start_x, height - 200, direction, 500, mi_scroll_payload)
                
        return True
    else:
        if max_scrolls == 0:
            # Final check for the element if the element comes up on the last scroll
            helper_instance.screenshot_base64 = driver.get_base64_screenshot()
            is_element_found = helper_instance.verify_element_found()
            if is_element_found:
                return True
        return False
 
def normalize_text(s: str, case_insensitive: bool = False, ascii_fold: bool = True) -> str:
    # check if commonparser.normalize_text is available
    try:
        if CommonParser:
            return CommonParser.normalize_text(s, case_insensitive=case_insensitive, ascii_fold=ascii_fold)
    except:
        if not s:
            return s
        return sanitize_visible_text(s)
    
    
def safe_cast_to_bool(value) -> bool:
    try:
        if CommonParser:
            return CommonParser()._safe_cast_to_bool(value)
    except:
        return value
    

def resolve_mathematical_operand(node, driver):
    node_name, node_type = next(iter(node.items()))
    value = None
    if node_type == "runtime_variable":
        value = string_to_float(access_value(user_variables, node_name, driver))
    elif node_type == "numeric_literal" or node_type == "parameter":
        value = string_to_float(node_name)
    elif node_type == "predefined_variable":
        predefined_variable = re.findall(r'\{\{(.*?)\}\}', node_name)[0]
        value = string_to_float(access_value(user_variables, predefined_variable, driver))
    else:
        return 0

    if value is None:
        return 0
    return value

def eval_math(node, driver):
    # Leaf
    if isinstance(node, (int, float)):
        return float(node)
    if isinstance(node, dict) and not "op" in node:
        return resolve_mathematical_operand(node, driver)

    # Branch
    op = node["op"]
    vals = [eval_math(child, driver) for child in node["operands"]]
    ops = {
        "add":       lambda a,b: a+b,
        "subtract":  lambda a,b: a-b,
        "multiply":  lambda a,b: a*b,
        "divide":    lambda a,b: a/b,
        "mod":       lambda a,b: a%b,
        "pow":       lambda a,b: a**b,
        "negate":    lambda a: -a,
        "abs":       lambda a: abs(a),
    }
    fn = ops[op]
    return fn(*vals) if len(vals)>1 else fn(vals[0])


def resolve_assertion_operand(node, driver):
    node_name, node_type = next(iter(node.items()))
    if node_type == "runtime_variable":
        value = access_value(user_variables, node_name, driver)
    elif node_type == "parameter":
        value = node_name
    elif node_type == "predefined_variable":
        predefined_variable = re.findall(r'\{\{(.*?)\}\}', node_name)[0]
        value = access_value(user_variables, predefined_variable, driver)
    print("value in resolve_assertion_operand: ", value, " node_name: ", node_name, " node_type: ", node_type)
    return value

def evaluate_assertion(tree: Mapping[str, Any], driver) -> bool:
    op = tree["operator"]

    # ----- logical nodes -----
    if op in {"AND", "OR", "NOT"}:
        ops = tree["operands"]
        if op == "AND":
            result = all(evaluate_assertion(t, driver) for t in ops)
            # if not result:
            #     raise AssertionError("AND condition failed - not all conditions were true")
            return result
        if op == "OR":
            result = any(evaluate_assertion(t, driver) for t in ops)
            # if not result:
            #     raise AssertionError("OR condition failed - none of the conditions were true")
            return result
        result = not evaluate_assertion(ops[0], driver)  # NOT
        # if not result:
        #     raise AssertionError("NOT condition failed")
        return result

    # ----- atomic nodes -----
    left = resolve_assertion_operand(tree["left_operand"], driver)
    right = None
    if tree.get("right_operand", None):
        right = resolve_assertion_operand(tree["right_operand"], driver)
    #  apply transforms if present
    if "transform_operands" in tree:
        if op in ["greater_than", "less_than", "greater_than_or_equal", "less_than_or_equal"]:
            if "string_to_float" not in tree["transform_operands"]:
                tree["transform_operands"].append("string_to_float")
        left = _apply_transform(left, tree["transform_operands"])
        if right is not None:
            right = _apply_transform(right, tree["transform_operands"])

    result = _compare_atomic(op, left, right)
    # if not result:
    #     raise AssertionError(f"Assertion failed for operation '{op}' with values {left} and {right}")
    return result

def _compare_atomic(op: str, a: Any, b: Any) -> bool:
    if op in {"equals", "equal"}  : return a == b or safe_cast_to_bool(a) == safe_cast_to_bool(b)
    if op in {"not_equal", "not_equals"}  : return a != b and safe_cast_to_bool(a) != safe_cast_to_bool(b)
    if op == "greater_than"   : return a >  b
    if op == "less_than"   : return a <  b
    if op == "greater_than_or_equal"  : return a >= b
    if op == "less_than_or_equal"  : return a <= b
    if op in {"start_with", "starts_with"}: return normalize_text(a, case_insensitive=True).startswith(normalize_text(b, case_insensitive=True))
    if op in {"end_with",   "ends_with"}  : return normalize_text(a, case_insensitive=True).endswith(normalize_text(b, case_insensitive=True))
    if op in {"contain", "contains"}      : return normalize_text(b, case_insensitive=True) in normalize_text(a, case_insensitive=True)
    if op == "lower_case": return normalize_text(a) == normalize_text(a, case_insensitive=True)
    if op == "upper_case": return normalize_text(a) == normalize_text(a, case_insensitive=True).upper()
    if op == "length_equals": return len(a) == len(b)
    if op == "type_equals": return type(a).__name__ == str(b)
    if op == "json_key_exists": return str(b) in _json_obj(a)
    if op == "json_keys_count": return len(_json_obj(a).keys()) == int(b)
    if op == "json_array_length_equals": return len(_json_arr(a)) == int(b)
    if op == "json_array_contains": return b in _json_arr(a)

    raise ValueError(f"Unsupported operator {op}")

def _json_obj(x: Any) -> Mapping[str, Any]:
    if isinstance(x, str):
        x = json.loads(x)
    return x

def _json_arr(x: Any) -> Sequence[Any]:
    if isinstance(x, str):
        x = json.loads(x)
    return x

def _apply_transform(val: Any, transform_name: list) -> Any:
    for transform in transform_name:
        if transform == "string_to_float":
            val = string_to_float(val)
    return val

def sanitize_visible_text(raw: str) -> str:
    """
    - Convert non-breaking spaces to a normal space.
    - Remove control / format characters (zero-width, bidi marks, etc.).
    - Collapse any run of whitespace (space, tab, newline) to a single space.
    - Trim leading / trailing whitespace.
    
    Feel free to extend the 'category' filter or add specific
    character replacements for your domain.
    """
    if not raw:
        return ""

    # &nbsp; → space
    cleaned = raw.replace("\u00A0", " ")

    # Strip control/format chars (Unicode categories Cc = control, Cf = format)
    cleaned = "".join(
        ch for ch in cleaned
        if unicodedata.category(ch) not in {"Cf", "Cc"}
    )

    # Collapse runs of whitespace to a single space
    cleaned = re.sub(r"\s+", " ", cleaned)

    return cleaned.strip()

def safe_value(element, driver, timeout: float = 2.0) -> str:
    element_text = element.text if hasattr(element, 'text') else ""
    return sanitize_visible_text(element_text)

def get_attribute(element, driver, selected_attribute: str):
    try:
        if selected_attribute == "text":
            value = safe_value(element, driver)
            return value
    except Exception as e:
        print(f"Error getting attribute: {e}")
        return None

# get current time helper
def get_current_utc_time():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

# get prev operation
def get_relative_prev_operation(operation_index: str) -> dict:
    try:
        prev_op_index = str(int(operation_index) - 1)
        return operations_meta_data.get(prev_op_index, {})
    except Exception as e:
        return {}

# get prev operation wait time
def get_prev_operation_wait_time(operation_index: str) -> float:
    wait_time = 0
    try:
        prev_operation = get_previous_executed_operation()
        if not prev_operation:
            prev_operation = get_relative_prev_operation(operation_index)
            
        prev_op_end_time = prev_operation.get('operation_end', '')
        curr_op_start_time = prev_operation.get('operation_start', '')
        
        if prev_op_end_time and curr_op_start_time:
            # Define the datetime format
            format = "%Y-%m-%d %H:%M:%S.%f"
            
            # Convert strings to datetime objects
            datetime1 = datetime.strptime(prev_op_end_time, format)
            datetime2 = datetime.strptime(curr_op_start_time, format)
            
            # Calculate the difference in seconds
            wait_time =  (datetime2 - datetime1).total_seconds()
    except Exception as e:
        print(f"Error getting prev operation wait time: {e}")
    
    return wait_time

# get operation wait time
def get_operation_wait_time(operation_index: str, default_wait_time: float = 5, max_additional_wait_time: float = 5 ) -> float:
    wait_time: float = 0
    try:
        explicit_wait = float(operations_meta_data[operation_index].get('explicit_wait', 0))
        wait_time = explicit_wait
        
        # get additional wait time depending on prev operation end time: to avoid delay in screen loading or slow internet issues
        additional_wait = default_wait_time
        prev_op_wait_time = get_prev_operation_wait_time(operation_index)
        if prev_op_wait_time > additional_wait:
            additional_wait = prev_op_wait_time
            
        # limit additional wait time in order to avoid false negatives or long waiting time
        additional_wait = min(additional_wait, max_additional_wait_time)
        
        wait_time += additional_wait
    except Exception as e:
        print(f"Error getting wait time: {e}")
        wait_time += default_wait_time # add default wait time
    
    return wait_time


# throttle network
def execute_network_throttle(driver, is_mobile_offline: bool, network_throttle: dict):
    value = network_throttle.get("value")

    try:
        if value != "custom":
            driver.execute_script(f"updateNetworkProfile={value}")
            print(f"Throttling Successfully Applied With Network Profile: {value}")
        else:
            download_speed = network_throttle.get("download_speed", 0)
            upload_speed = network_throttle.get("upload_speed", 0)
            latency = network_throttle.get("latency", 0)
            driver.execute_script(f"customNetworkProfile:{{ \\\"downloadSpeed\\\": {download_speed},\\\"uploadSpeed\\\" : {upload_speed}, \\\"latency\\\": {latency} }}")
            print(f"Throttling Successfully Applied With Custom Network Profile: downloadSpeed: {download_speed}, uploadSpeed: {upload_speed}, latency: {latency}")
        
        time.sleep(2) # wait for 2 seconds to apply the network throttle
    except Exception as e:
        raise Exception(f"Error executing network throttle: {e}")


# initialize network throttle
def initialize_network_throttle(driver):
    
    value = os.getenv("NETWORK_PROFILE", "default")

    if value != "default":
        network_throttle = {
            "value": value,
            "download_speed": int(os.getenv("DOWNLOAD_SPEED", 0)),
            "upload_speed": int(os.getenv("UPLOAD_SPEED", 0)),
            "latency": int(os.getenv("LATENCY", 0))
        }
        
        execute_network_throttle(driver, is_mobile_offline=False, network_throttle=network_throttle)
        
# lambda hooks execution support
def execute_lambda_hooks(driver, hook, argument):
    print(f"*********** [{get_current_utc_time()}]:: Executing hook: '{hook}' = '{argument}'")
    driver.execute_script(f"{hook}={argument}")

# lambda test case start
def lambda_test_case_start(driver, test_case_name):
    try:
        execute_lambda_hooks(driver, "lambda-testCase-start", test_case_name)
    except Exception as e:
        print(f"Failed to update lambda-testCase-start={test_case_name} due to error: {e}")

# lambda test case end    
def lambda_test_case_end(driver, test_case_name):
    try:
        execute_lambda_hooks(driver, "lambda-testCase-end", test_case_name)
    except Exception as e:
        print(f"Failed to update lambda-testCase-end={test_case_name} due to error: {e}")

# get test case name
def get_test_case_name(operation_index, driver):
    default_test_case_name = f"[{operation_index}]: "
    
    op_intent = get_variable_value(str(operations_meta_data[operation_index].get("operation_intent", "")), driver)
    op_type = str(operations_meta_data[operation_index].get("operation_type", ""))
    sub_instruction_obj = operations_meta_data[operation_index].get('sub_instruction_obj', {})
    
    if isinstance(sub_instruction_obj, str):
        try:
            sub_instruction_obj = json.loads(sub_instruction_obj)
        except Exception as e:
            sub_instruction_obj = {}
              
    test_case_name = f"{default_test_case_name} '{op_intent}'"
    if not op_intent or len(test_case_name) > 255: 
        test_case_name = f"{default_test_case_name} '{op_type}'"
        
    if len(test_case_name) > 255:
        test_case_name = default_test_case_name

    test_case_name = get_variable_value(test_case_name, driver)

    return test_case_name

# scroll helper to get coordinates
def get_scroll_coordinates(
    screen_coordinates: List[int],
    direction: str, 
    value: int,
    is_percent_value: bool = False
) -> tuple[int, List[int]]:
    """
    Calculate the start and end coordinates for scrolling based on direction and value.

    Args:
        screen_coordinates (List[int]): Scrollable Section bounds.
        direction (str): Direction to scroll ('up', 'down', 'left', 'right').
        value (int): Distance to scroll in pixels.
        is_percent_value (bool): If True, value is a percentage of the screen size.

    Returns:
        tuple[int, List[int]]: (loop_range, [start_x, start_y, end_x, end_y])
    """
    direction = direction.lower()
    start_screen_x, start_screen_y, end_screen_x, end_screen_y = screen_coordinates
    
    # Sort coordinates to ensure proper order
    min_x = min(start_screen_x, end_screen_x)
    max_x = max(start_screen_x, end_screen_x)
    min_y = min(start_screen_y, end_screen_y)
    max_y = max(start_screen_y, end_screen_y)
    
    # Calculate screen width and height
    screen_width = abs(max_x - min_x)
    screen_height = abs(max_y - min_y)
    
    # Default scroll distance if no value provided
    single_scroll_distance_percent = 50 if direction in ['up', 'down'] else 70
    if value <= 0:
        value = single_scroll_distance_percent
        is_percent_value = True
    
    if is_percent_value:
        value = int(screen_height * value / 100) if direction in ['up', 'down'] else int(screen_width * value / 100)
        
    value = int(value)

    # Fix start coordinates to middle of the element
    start_x = (min_x + max_x) // 2
    start_y = (min_y + max_y) // 2
    
    scroll_val = int(screen_height * single_scroll_distance_percent / 100) if direction in ['up', 'down'] else int(screen_width * single_scroll_distance_percent / 100)
    scroll_val = min(value, scroll_val) # in case value is less than scroll_val
    
    # Determine end coordinates based on the direction
    end_x, end_y = start_x, start_y
    if direction == 'up':
        end_y = start_y + scroll_val - 1
    elif direction == 'down':
        end_y = start_y - scroll_val + 1
    elif direction == 'left':
        start_x = min(min_x + 65, start_x)
        end_x = start_x + scroll_val - 1
    elif direction == 'right':
        start_x = max(max_x - 65, start_x)
        end_x = start_x - scroll_val + 1
    else:
        raise ValueError("Invalid direction. Use 'up', 'down', 'left', or 'right'.")

    # Ensure start and end points are within bounds
    start_x = max(min_x, min(start_x, max_x - 1))
    start_y = max(min_y, min(start_y, max_y - 1))
    end_x = max(min_x, min(end_x, max_x - 1))
    end_y = max(min_y, min(end_y, max_y - 1))
    
    # Calculate loop range based on the scroll value
    single_scroll_distance_covered = abs(start_y - end_y) if direction in ['up', 'down'] else abs(start_x - end_x)
    loop_range = math.ceil(value / single_scroll_distance_covered)
    
    return (loop_range , [start_x, start_y, end_x, end_y])

# returns element and corresponding locator
def find_element(driver: WebDriver, locators: list, operation_idx: str, max_retries: int = 2, current_retry: int = 0) -> tuple[str, str]:
    wait_times = [10, 5, 3]
    for i, locator in enumerate(locators):
        if not locator:
            continue
        try:
            driver.implicitly_wait(wait_times[i%3]) # set implicit wait time
            element = driver.find_element(By.XPATH, locator)
            if element:
                print(f"Element found with locator: {locator}")
                return element, locator
        except:
            pass

    if current_retry >= max_retries:
        print("MAX RETRIES EXCEEDED")
        return None, None

    # retry healing xpaths
    time.sleep(1.5) # add delay to avoid false negatives like loading screen or slow network
    print("Trying autoheal.. Unable to find element in locators: ", locators)
    healed = AutoHealer(driver).get_healed_xpaths(operation_idx)

    # When QWEN coordinate model wins, return coordinate dict instead of element
    if isinstance(healed, dict) and healed.get('is_coordinates_used_for_interaction'):
        return None, healed

    return find_element(driver, healed, operation_idx, max_retries, current_retry + 1) # Recursively retry with healed locators

# handle unresolved operations
def handle_unresolved_operations(operations_meta_data, operation_index, driver) -> bool:
    unresolved_operation = operations_meta_data[operation_index]
    
    action = operations_meta_data[operation_index]['operation_type']
    sub_instruction_obj = operations_meta_data[operation_index].get('sub_instruction_obj', {})
    if isinstance(sub_instruction_obj, str):
        sub_instruction_obj = json.loads(sub_instruction_obj)

    # check is operation is unresolved
    is_unresolved = ('unresolved' in unresolved_operation) and (isinstance(unresolved_operation['unresolved'], bool)) and (unresolved_operation['unresolved'])

    is_unresolved_action = action.lower() in ['click', 'clear']
    if is_unresolved_action and (sub_instruction_obj.get('variable', {}).get('operation_intent', None) or sub_instruction_obj.get('params', {}).get('operation_intent', None)):
        is_unresolved = True
    
    if not is_unresolved:
        return False
    
    # replace variable in operations
    updates = {}
    updates['operation_intent'] = operations_meta_data[operation_index].get('operation_intent', '')
    sub_instruction_obj['operation'] = updates['operation_intent']
    updates['sub_instruction_obj'] = json.dumps(sub_instruction_obj)
    
    if 'agent' in sub_instruction_obj:
        updates['agent'] = sub_instruction_obj['agent']

    update_operation_meta_data(operation_index, updates)
    print("Resolving unresolved operation, Operation Intent:", operations_meta_data[operation_index]['operation_intent']) # To Do: currently, it works correctly if resolved result is a single operation, may fail if resolve case result in multiple operations
    
    agent = unresolved_operation.get('agent', '')
    if agent == "Vision Agent":
        response = AutoHealer(driver).resolve_operation(operation_index, max_attempts=2)

        if response is None:
            raise RuntimeError("Error in resolving operation: response is None")
        
        # add resolved xpath to locator key
        if response.get('xpath', None):
            response['locator'] = [response.get('xpath')]
        
        # add alternate xpaths to locator key
        alternate_xpaths = response.get('alternative_xpaths', [])
        if alternate_xpaths is not None and isinstance(alternate_xpaths, list) and len(alternate_xpaths) > 0:
            response['locator'].extend(alternate_xpaths)
        
        
        update_operation_meta_data(operation_index, response)
        
    # return true by default
    return True


# handle coordinates
def get_new_coordinates_ratio_for_operation(operation_index, driver) -> tuple[list, list]:
    findTime = time.time()
    element_coordinates_ratio, element_bounds_ratio = AutoHealer(driver).resolve_coordinates(operation_index)
    if element_coordinates_ratio is None and element_bounds_ratio is None:
        raise RuntimeError("Error in resolving new coordinates: response is None")
    print(f"Coordinates resolved in {time.time() - findTime} seconds")
    return element_coordinates_ratio, element_bounds_ratio
    


# finds element and returns xml if exist
def fetch_element_xml(page_source, xpath: str):
    try:
        # Convert the page source to bytes if it contains an encoding declaration
        if isinstance(page_source, str):
            page_source = page_source.encode('utf-8')

        root = etree.fromstring(page_source)
        xml_elements = root.xpath(xpath)

        if len(xml_elements) == 0:
            return None
        else:
            return etree.tostring(xml_elements[0], pretty_print=True, encoding='unicode')
    except Exception as e:
        print(f"Error: {e}")
        return None

def access_value(mapping, path, driver):
    global smart_variables_cache
    
    try:
        keys = path.split('.')
        if keys[0] == 'smart' and len(keys) == 2:
            smart_variables = None
            if smart_variables_cache != None:
                smart_variables = smart_variables_cache
            else:
                smart_variables = SmartVariables()
                smart_variables_cache = smart_variables
            
            # Check if driver is a WebDriver object before accessing orientation
            try:
                if hasattr(driver, 'orientation'):
                    smart_variables.device_orientation = driver.orientation
            except Exception:
                pass
                
            return smart_variables.get(keys[1])
        value = mapping
        for key in keys:
            while '[' in key and ']' in key:
                base_key, index = key.split('[', 1)
                index = int(index.split(']')[0])
                value = value[base_key] if base_key else value
                value = value[index]
                key = key[key.index(']') + 1:] 
            if key: 
                value = value[key]

        return str(value)
    except (KeyError, IndexError, ValueError, TypeError):
        return path

class SmartVariables:
    def __init__(self):
        # Instance attributes
        current_datetime = datetime.now()
        self.current_date = current_datetime.strftime("%Y-%m-%d")
        self.current_day = current_datetime.strftime("%A")
        self.current_month_number = current_datetime.strftime("%m")
        self.current_year = current_datetime.strftime("%Y")
        self.current_month = current_datetime.strftime("%B")
        self.current_hour = current_datetime.strftime("%H")
        self.current_minute = current_datetime.strftime("%M")
        self.current_timestamp = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
        self.current_timezone = time.strftime("%Z")

        self.next_day = (current_datetime + timedelta(days=1)).strftime("%Y-%m-%d")
        self.previous_day = (current_datetime - timedelta(days=1)).strftime("%Y-%m-%d")
        self.start_of_week = (current_datetime - timedelta(days=current_datetime.weekday())).strftime("%Y-%m-%d")
        self.end_of_week = (current_datetime + timedelta(days=6-current_datetime.weekday())).strftime("%Y-%m-%d")
        self.start_of_month = (current_datetime.replace(day=1)).strftime("%Y-%m-%d")
        self.end_of_month = (current_datetime.replace(day=calendar.monthrange(current_datetime.year, current_datetime.month)[1])).strftime("%Y-%m-%d")
        self.random_int = str(random.randint(100, 999))
        self.random_float = str(round(random.uniform(1, 100), 2))
        self.random_string_8 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
        self.random_string_56 = ''.join(random.choices(string.ascii_letters + string.digits, k=56))
        self.random_email = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10)) + "@example.com"
        self.random_phone = f"{random.randint(1000000000,9999999999)}"

        # Environment and system info constants
        self.user_name = os.getenv('LT_USERNAME', '')
        self.device_name = os.getenv("deviceName","")
        self.app_package_name = os.getenv("app","")
        self.app_version = os.getenv("appVersion","")
        self.device_os = os.getenv("platformName","")
        self.device_os_version = os.getenv("platformVersion","")
        self.device_orientation = "portrait"

        # Location and IP information
        self.country = "India"
        self.city = "Doddaballapura"
        self.latitude = "13.2257"
        self.longitude = "77.5750"
        self.ip_address = "143.110.182.88"
    
    def get(self, name: str):
        return getattr(self, name)

class TestVariable:
    def __init__(self, global_variables = [], environment_id = 0, user_data: dict = None):
        if not user_data:
            user_data = {}
        self.username: str = os.getenv('LT_USERNAME',user_data.get('username',''))
        self.access_key: str = os.getenv('LT_ACCESS_KEY',user_data.get('access_key',''))
        self.global_variables = global_variables
        self.url = os.getenv("ATMS_URL", user_data.get('atms_url', ''))
        self.environment_id = environment_id

    def get_variable_value_by_name(self, variable_name: str):
        url = f"{self.url}/api/v1/variables/{variable_name}?environment_id={self.environment_id}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {base64.b64encode(f'{self.username}:{self.access_key}'.encode()).decode()}"
        }
        
        response = make_http_request_with_retry("GET", url=url, headers=headers)
        if response.status_code != 200:
            raise Exception(f"Failed to make the request. Error: {response.text}")
        
        try:
            response = response.json()
        except ValueError as e:
            raise Exception(f"Failed to parse JSON response. Error: {str(e)}")
        return response["data"]
    
    def update_session_variable_value(self, variable_name: str, value: str):
        for variable in self.global_variables:
            if variable.get("name") == variable_name and variable.get("environment_id") == self.environment_id:
                variable["session_value"] = value
                break
        set_global_variables(self.global_variables)
    
    def update_session_variable_value_by_id(self, variable_id: int, value: str):
        for variable in self.global_variables:
            if variable.get("id") == int(variable_id):
                variable["session_value"] = value
                break
        set_global_variables(self.global_variables)

    def update_session_variable_value_by_name(self, variable_name: str, value: str):
        for variable in self.global_variables:
            if variable.get("name") == variable_name:
                variable["session_value"] = value
                break
        set_global_variables(self.global_variables)

    def get_session_variable_value(self, variable_name: str):
        for variable in self.global_variables:
            if variable.get("name") == variable_name and variable.get("environment_id") == self.environment_id:
                if "session_value" in variable:
                    return variable.get("session_value")
                else:
                    return variable.get("value")
        return None

    def update_variable_value(self, variable_id: str, value: str):
        url = f"{self.url}/api/v1/variables/{variable_id}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {base64.b64encode(f'{self.username}:{self.access_key}'.encode()).decode()}"
        }
        payload = {
            "value": value,
            "value_type": "string"
        }
        response = make_http_request_with_retry("PUT", url=url, headers=headers, json_data=payload)
        if response.status_code != 200:
            raise Exception(f"Failed to make the request. Error: {response.text}")
        
        try:
            response = response.json()
        except ValueError as e:
            raise Exception(f"Failed to parse JSON response. Error: {str(e)}")
        return response

    def update_variable_value_by_name(self, variable_name: str, value: str, environment_id: int=0):
        global_persist_flag = False
        url = f"{self.url}/api/v1/variables/name/{variable_name}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {base64.b64encode(f'{self.username}:{self.access_key}'.encode()).decode()}"
        }
        payload = {
            "value": value,
            "value_type": "string",
            "type": "variable",
            "environment_id": environment_id
        }
        try:
            response = make_http_request_with_retry("PUT", url=url, headers=headers, json_data=payload)
            if response.status_code == 200:
                global_persist_flag = True
            elif response.status_code == 403:
                global_persist_flag = False

        except Exception as e:
            raise Exception(f"Failed to make the request to update variable value by name. Error: {e.__str__()}")
        
        return global_persist_flag
    
    
def generate_totp_code(secret):
    try:
        # Clean the secret by removing spaces, hyphens and converting to uppercase
        cleaned_secret = secret.replace('-', '').replace(' ', '').upper()
        
        # Validate the secret is not empty
        if not cleaned_secret:
            print("Error: Invalid TOTP secret",secret)
            return None
            
        # Generate TOTP code
        totp = pyotp.TOTP(cleaned_secret)
        code = totp.now()
            
        return code
    except Exception as e:
        print(f"Error generating TOTP code: {e}")
        return secret
    
def handle_totp_variable(match: str) -> str:
    name = match.split(".")[1]
    key = user_variables.get(f"{name}", "") #NOTE: this can lead to conflicts in case of system generated totp collides with user defined var
    if key.startswith('{{secrets.'):
        key = key.replace("}}", "")
        key = key.replace("{{", "")
        key = os.getenv(key.split('.')[2], '')
    return generate_totp_code(key)        


def get_parameter_value(value: str, parameters: dict = None) -> str:
    """
    Resolves parameter placeholders in the format ${parameter_name}
    Supports nested paths like ${user.email} or ${items[0].name}
    
    Args:
        value: String that may contain ${...} placeholders
        parameters: Dictionary of parameters (defaults to global user_parameters)
    
    Returns:
        String with all ${...} placeholders replaced with actual values
    """
    if parameters is None:
        parameters = user_parameters
    
    if not value or not isinstance(value, str):
        return value
    
    matches = re.findall(r'\$\{(.*?)\}', value)
    new_value = value
    
    if matches:
        for match in matches:
            if match == "":
                continue
            accessed_value = access_value(parameters, match, None)
            if accessed_value is not None:
                new_value = new_value.replace("${"+match+"}", str(accessed_value))
    
    return new_value


def get_variable_value(value: str, driver, variables: dict = None) -> str:
    if not variables:
         variables = user_variables
    matches = re.findall(r'\{\{(.*?)\}\}', value)
    new_value = value
    # check for variable matches
    if matches:
        for match in matches:
            if match == "":
                continue
            if match.split(".")[0] == 'global' and len(match.split(".")) > 1:
                test_variable = TestVariable(global_variables=global_variables)
                variable = test_variable.get_variable_value_by_name(match.split(".")[1])
                variable_value = variable["value"]
                if not variable["is_persist"]:
                    session_variable_value = test_variable.get_session_variable_value(match.split(".")[1])
                    if session_variable_value is not None:
                        variable_value = session_variable_value
                new_value = new_value.replace("{{"+match+"}}", str(variable_value))
                continue
            if match.split(".")[0] == "environment" and len(match.split(".")) > 1:
                test_variable = TestVariable(global_variables=global_variables, environment_id=int(os.getenv("ENVIRONMENT_ID", 0)))
                variable_value = test_variable.get_variable_value_by_name(match.split(".")[1])["value"]
                new_value = new_value.replace("{{"+match+"}}", str(variable_value))
                continue

            if match.split(".")[0] == 'smart' and len(match.split(".")) > 1 and match.split(".")[1].startswith('totp_'):
                new_value = new_value.replace("{{"+match+"}}", str(handle_totp_variable(match)))
                continue
            if match.split(".")[0] == "secrets" and len(match.split(".")) == 3:
                new_value = new_value.replace("{{"+match+"}}", os.getenv(match.split('.')[2], ''))
                continue
            new_value = new_value.replace("{{"+match+"}}", access_value(variables, match, driver))
            
    # check for param matches
    matches = re.findall(r'\$\{(.*?)\}', new_value)
    if matches:
        new_value = get_parameter_value(new_value, user_parameters)

    return new_value

def replace_apivar(request_args, driver):
    for (key,value) in request_args.items():
        if isinstance(value, str):
            request_args[key]=get_variable_value(request_args[key], driver)
        elif isinstance(value, dict):
            final_val_dict = {}
            for (key2,value2) in value.items():
                sanitised_key = get_variable_value(key2, driver)
                final_val_dict[sanitised_key]=value2
                if isinstance(value2, str):
                    final_val_dict[sanitised_key]=get_variable_value(value2, driver)
            request_args[key]=final_val_dict
    return request_args

def parse_urlencoded_body(encoded_input, driver) -> str:
    # parse_qsl will:
    # - split on & and =
    # - decode percent-encoding
    # - treat '+' as space (via encoding rules for x-www-form-urlencoded)
    pairs = parse_qsl(encoded_input, keep_blank_values=True, strict_parsing=False)

    new_pairs = []
    for k, v in pairs:
        # Apply your variable substitution logic on key/value as you need
        # Usually variables are in values, but doing both is safest.
        k2 = get_variable_value(k, driver)
        v2 = get_variable_value(v, driver)
        new_pairs.append((k2, v2))

    # Re-encode properly for x-www-form-urlencoded (spaces -> '+')
    return urlencode(new_pairs, doseq=True)


def preprocess_subinstruction_object(operation_index, driver):
    sub_instruction_obj = operations_meta_data[operation_index].get('sub_instruction_obj', {})
    if isinstance(sub_instruction_obj, str):
        sub_instruction_obj = json.loads(sub_instruction_obj)
    if isinstance(sub_instruction_obj, dict):
        # [TE-1783 FIX] Generic resolution of all variable templates
        # Iterate over all keys in 'variable' and resolve them
        if 'variable' in sub_instruction_obj and isinstance(sub_instruction_obj['variable'], dict):
            for key, template in sub_instruction_obj['variable'].items():
                if not isinstance(template, str):
                    continue

                resolved_value = get_variable_value(template, driver=driver)

                # Special handling for operation_intent -> updates 'operation' field
                if key == 'operation_intent':
                    sub_instruction_obj['operation'] = resolved_value

                # Update corresponding key in operation_dict if it exists
                if 'operation_dict' in sub_instruction_obj and key in sub_instruction_obj['operation_dict']:
                    sub_instruction_obj['operation_dict'][key] = resolved_value

            operations_meta_data[operation_index]['sub_instruction_obj'] = json.dumps(sub_instruction_obj)

        # Resolve from params if it exists (params takes precedence - original behavior)
        if 'params' in sub_instruction_obj and isinstance(sub_instruction_obj['params'], dict):
            for key, template in sub_instruction_obj['params'].items():
                if not isinstance(template, str):
                    continue

                resolved_value = get_variable_value(template, driver=driver)

                # Update corresponding key in operation_dict if it exists
                if 'operation_dict' in sub_instruction_obj and key in sub_instruction_obj['operation_dict']:
                    sub_instruction_obj['operation_dict'][key] = resolved_value

            operations_meta_data[operation_index]['sub_instruction_obj'] = json.dumps(sub_instruction_obj)
#########################################################################################################



############################################## Smart Wait Methods ##############################################################

def smart_wait_on_action(driver: WebDriver, is_ios: bool, curr_action: str, prev_action: str, logger = None):
    # determine current action
    action = curr_action.lower()
    smart_wait_actions = ["click", "type", "search", "clear", "scroll", "vision_query", "textual_query", "visual_query"]
    
    # check if current action needs wait
    is_smart_wait_action = False
    for act in smart_wait_actions:
        if action.startswith(act):
            is_smart_wait_action = True
            break
        
    if not is_smart_wait_action:
        print(f"{action} action does not require smart wait.")
        return
    
    # get previous action type
    state_change_actions = ["click", "type", "search", "clear", "scroll", "navigate", "keyevent", "orientation", "deeplink", "network_throttle", "enter", "open_app", "switch_app", "background", "wait"] #added wait as sometimes explicit wait might not be enough
    previous_action =  prev_action.lower()
    if previous_action:
        is_previous_action_state_changing = False
        for act in state_change_actions:
            if previous_action.startswith(act):
                is_previous_action_state_changing = True
                break
        if not is_previous_action_state_changing:
            print(f"Skipping smart wait as previous action '{previous_action}' is non state changing.")
            return
    else:
        print("No previous action found, proceeding with smart wait.")
        
    # vision actions
    vision_actions = ["vision_query", "textual_query", "visual_query"]
    
    # decide wait strategy
    smart_wait_config = get_feature_flags().get_smart_wait_config(is_ios)
    if smart_wait_config.get("auto", False):
        max_wait_Time = smart_wait_config.get("vision", 10) if action in vision_actions else smart_wait_config.get("non_vision", 10)
        print(f"Performing smart wait for '{action}' operation with approx timeout of {max_wait_Time} seconds.")
        SmartWaitAppium(driver=driver, is_ios=is_ios, wait_config=smart_wait_config, logger=logger).wait_till_screen_loads(timeout=max_wait_Time)
        return
    
    #decide non smart operation wait times
    max_wait_Time = smart_wait_config.get("vision", 6) if action in vision_actions else smart_wait_config.get("non_vision", 1.5)
    
    if not isinstance(max_wait_Time, float):
        try:
            max_wait_Time = float(str(max_wait_Time))
        except:
            max_wait_Time = 1.5
            
    if not max_wait_Time:
        max_wait_Time = 1.5
    
    print(f"Performing smart wait for {max_wait_Time} seconds before executing '{action}' operation.")
    time.sleep(max_wait_Time)
    return


def smart_wait(customDriver: CustomAppiumDriver, operation_index: str):
    # determine current action
    curr_action = operations_meta_data[operation_index].get('operation_type', '').lower()
    previous_action =  get_previous_executed_operation().get('operation_type', '').lower()
    is_ios = customDriver.is_ios()
    return smart_wait_on_action(customDriver.driver, is_ios, curr_action, previous_action, logger=None)
    


#########################################################################################################



############################# Main Methods used in test.py #################################################

# string to float execution
def string_to_float(input_string):
    if isinstance(input_string, float):
        return input_string
    if isinstance(input_string, int):
        return float(input_string)
    if not isinstance(input_string, str):
        input_string = str(input_string)
        
    filtered_input = ''.join(filter(lambda x: x.isdigit() or x == '.', input_string))
    
    # Check if the result is empty, return 0
    if not filtered_input:
        return 0
    
    return float(filtered_input)

# prints the argument: just for debugging, main method is 'execute_lambda_hooks': use if required
def lambda_hooks(driver, argument):
    argument = get_variable_value(argument, driver)
    print(argument)
    
# perform assertion based on operator
def perform_assertion(driver, operation_index, operand1, operator, operand2, assertion = ""):
    # execute test case start
    sub_instruction_obj = operations_meta_data[str(operation_index)].get('sub_instruction_obj', {})
    if isinstance(sub_instruction_obj, str):
        sub_instruction_obj = json.loads(sub_instruction_obj)
    is_string_to_float = operations_meta_data[str(operation_index)].get('string_to_float', False)
    failure_condition = operations_meta_data[operation_index].get('failure_condition', '')
    if isinstance(sub_instruction_obj, dict) and 'json' not in operator:
        if 'params' in sub_instruction_obj:
            if 'operand1' in sub_instruction_obj['params']:
                new_value = str(operations_meta_data[str(operation_index)]['queried_value'])
                if is_string_to_float:
                    operand1 = string_to_float(new_value)
                else:
                    operand1 = new_value.lower()
            if 'operand2' in sub_instruction_obj['params']:
                new_value = str(operations_meta_data[str(operation_index)]['expected_value'])
                if is_string_to_float:
                    operand2 = string_to_float(new_value)
                else:
                    operand2 = new_value.lower()
        if 'variable' in sub_instruction_obj:
            if 'operand1' in sub_instruction_obj['variable']:
                new_value = get_variable_value(sub_instruction_obj['variable']['operand1'], driver)
                if is_string_to_float:
                    operand1 = string_to_float(new_value)
                else:
                    operand1 = new_value.lower()
            if 'operand2' in sub_instruction_obj['variable']:
                new_value = get_variable_value(sub_instruction_obj['variable']['operand2'], driver)
                if is_string_to_float:
                    operand2 = string_to_float(new_value)
                else:
                    operand2 = new_value.lower()
    curr_test_case_name = f"""[{operation_index}]: Asserting [({operand1})  {operator}  ({operand2})]"""
    if len(curr_test_case_name) > 255:
        curr_test_case_name = f"""[{operation_index}]: Asserting [{operator}] operation"""
        
    lambda_test_case_start(driver, curr_test_case_name)

    print(f"""\n***** Executing Assertion operation: [({operand1}) {operator} ({operand2})]: """)
    hard_assertion = operations_meta_data[str(operation_index)].get('hard_assertion', False)
    try:
        if operator == "json_key_exists":
            assert operand2 in operand1.keys(), f"Key '{operand2}' does not exist in the JSON object."
        elif operator == "json_keys_count":
            assert len(operand1.keys()) == int(operand2), f"Expected {operand2} keys, but found {len(operand1.keys())}."
        elif operator == "json_array_length":
            assert len(operand1) == int(operand2), f"Expected array length {operand2}, but found {len(operand1)}."
        elif operator == "json_array_contains":
            assert operand2 in operand1, f"Array does not contain the value '{operand2}'."
        elif operator == "json_value_equals":
            assert operand1 == operand2, f"Expected value '{operand2}', but found '{operand1}'."
        elif operator == "==":
            assert (operand1 == operand2 or safe_cast_to_bool(operand1) == safe_cast_to_bool(operand2)), f"Expected {operand1} to equal {operand2}"
        elif operator == "!=":
            assert (operand1 != operand2 and safe_cast_to_bool(operand1) != safe_cast_to_bool(operand2)), f"Expected {operand1} to not equal {operand2}"
        elif operator == "true":
            assert operand1, f"Expected true, got {operand1}"
        elif operator == "false":
            assert not operand1, f"Expected false, got {operand1}"
        elif operator == "is_null":
            assert operand1 is None, "Expected operand to be None"
        elif operator == "not_null":
            assert operand1 is not None, "Expected operand to be not None"
        elif operator == "contains":
            assert normalize_text(operand2) in normalize_text(operand1), f"Expected {operand2} to be in {operand1}"
        elif operator == "not_contains":
            assert normalize_text(operand2) not in normalize_text(operand1), f"Expected {operand2} to not be in {operand1}"
        elif operator == ">":
            assert operand1 > operand2, f"Expected {operand1} to be greater than {operand2}"
        elif operator == "<":
            assert operand1 < operand2, f"Expected {operand1} to be less than {operand2}"
        elif operator == ">=":
            assert operand1 >= operand2, f"Expected {operand1} to be greater than or equal to {operand2}"
        elif operator == "<=":
            assert operand1 <= operand2, f"Expected {operand1} to be less than or equal to {operand2}"
        print("Assertion passed\n")
        
    except AssertionError as e:
        print(f"Assertion [{assertion}] failed :: {str(e)} \n")
        if hard_assertion:
            # execute test case end lambda hook
            lambda_test_case_end(driver, curr_test_case_name)
            raise e
        if failure_condition == FailureCondition.FAIL_TEST_IMMEDIATELY.value or failure_condition == FailureCondition.NONE.value:
            raise RuntimeError(f"Assertion failed: '{curr_test_case_name}' - {str(e)}")
        elif failure_condition == FailureCondition.FAIL_BUT_CONTINUE_EXECUTING.value:
            set_test_status("failed")

    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)

# textual query
def query(driver: WebDriver, operation_index: str):
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)
    
    # resolve operation if unresolved
    is_resolved = handle_unresolved_operations(operations_meta_data, operation_index, driver)
    
    custom_driver = CustomAppiumDriver(driver)
    
    locators = operations_meta_data[operation_index]['locator']
    regex_pattern = operations_meta_data[operation_index]['regex_pattern']
    utility = operations_meta_data[operation_index]['string_to_float']
    element, locator = find_element(driver, locators, operation_index, 2, 0)
    
    if element is None and utility:
        # execute test case end lambda hook
        lambda_test_case_end(driver, curr_test_case_name)
        return 0
    elif element is None and not utility:
        # execute test case end lambda hook
        lambda_test_case_end(driver, curr_test_case_name)
        return ""
    
    html = fetch_element_xml(custom_driver.get_page_source_with_webview_wait(), locator)
    html = html.replace('"', "'").replace("\n", "")
    attributes = ['data-node-id' , 'data-auteur-element-id', 'data-original-border-style' , 'data-original-position', 'data-original-padding-top', 'data-original-padding-left', 'data-original-width', 'data-original-height', 'data-original-max-width', 'data-original-max-height', 'data-original-display', 'manual-interaction-id']
    for attribute in attributes:
        html = re.sub(rf'{attribute}=\'.*?\'', '', html)
    
    regex = base64.b64decode(regex_pattern).decode("utf-8")
    match = re.search(fr"{regex}", html)
    if utility:
        # execute test case end lambda hook
        lambda_test_case_end(driver, curr_test_case_name)
        return string_to_float(match.group(1)) if match else 0

    set_query_operation_output_variable(operation_index=operation_index, var_value=match.group(1))
    
    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    return match.group(1) if match else ""

# visual query
def vision_query(driver: WebDriver, operation_index: str):
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)
    
    # wait before performing vision query
    smart_wait(CustomAppiumDriver(driver), operation_index)
    
    autohealer = AutoHealer(driver)

    preprocess_subinstruction_object(operation_index, driver)

    response = autohealer.get_healed_vision_query(operation_index)
    set_query_operation_output_variable(operation_index=operation_index, var_value=response)
    
    if response is None:
        raise RuntimeError("Error in vision query: response is None")
    
    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    return response

def replace_secrets(text: str) -> str:
    matches = re.findall(r'\{\{(.*?)\}\}', text)
    for match in matches:
        keys = match.split('.')
        if len(keys) == 3 and keys[0] == 'secrets':
            secret_value = os.getenv(keys[2], '')
            text = text.replace(f"{{{{{match}}}}}", secret_value)

    return text

def replace_secrets_in_dict(d: Dict[str, str]) -> Dict[str, str]:
    new_dict = {}
    for k, v in d.items():
        replaced_key = replace_secrets(k)
        replaced_value = replace_secrets(v)
        if replaced_key == 'Authorization' and not replaced_value.startswith('Bearer') and not replaced_value.startswith('AWS'):
            replaced_split = replaced_value.split(':')
            if len(replaced_split) > 1:
                username = replaced_split[0]
                access_key = replaced_split[1]
                replaced_value = f"Basic {base64.b64encode(f'{username}:{access_key}'.encode()).decode()}"

        new_dict[replaced_key] = replaced_value

    return new_dict


# api testing execution
def execute_api_action(driver: WebDriver, operation_index: str):
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)

    original_payload = operations_meta_data[operation_index]
    
    if original_payload.get("dummyrequest", {}) != {}:
        payload = original_payload.get("dummyrequest").copy()
    else:
        payload = original_payload.copy()

    payload["headers"] = replace_secrets_in_dict(payload.get("headers", {}))
    
    auth = payload.get("authorization", {})
    if isinstance(auth, dict) and auth and auth.get('data'):
        auth_data = replace_apivar(auth.get("data").copy(), driver)
        auth['data'] = auth_data
        payload["authorization"] = auth

    url, headers, body, params = replace_apivar({'url':payload["url"], 'headers':payload["headers"].copy(), 'body':payload["body"], 'params':payload["params"].copy()},driver).values()
    
    # check for url encoded body if application type is "application/x-www-form-urlencoded"
    if headers and isinstance(headers, dict):
        content_type = headers.get("Content-Type") or headers.get("content-type")
        content_type = str(content_type)
        if content_type and content_type.lower() == "application/x-www-form-urlencoded" and body and isinstance(body, str):
            body = parse_urlencoded_body(encoded_input=body, driver=driver)
            
    payload["url"]=url
    payload["headers"]=headers
    payload["body"]=body
    payload["params"]=params

    
    # execute via lambda hook
    args = {
            "command": "executeAPI",
            "testId":  driver.session_id,
            "payload": payload
        }
    response = driver.execute_script("lambda-kane-ai", args)
    
    # set user var name
    set_operation_output_user_variable(operation_index=operation_index, var_value=response)
    
    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    return response

# main function to execute script
def execute_script_action(driver: WebDriver, operation_index: str):
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)

    from code_executor import CodeExecutor, ScriptExecutionMode
    meta_data = operations_meta_data[operation_index]
    code_executor = CodeExecutor(
        driver=driver,
        code_snippet=meta_data.get('script_content'),
        script_type=meta_data.get('script_type'),
        predefs=get_all_runtime_variables(),
        timeout_sec=meta_data.get('timeout_sec', None),
        execution_mode_params = {
            "mode": ScriptExecutionMode.LAMBDA_HOOK.value,
        }
    )
    lambda_hook_args = {
        "is_mobile": True,
        "mobile_browser": False
    }
    script_resp = code_executor.execute_sync(lambda_hook_args=lambda_hook_args)
    if script_resp.get("error", None):
        raise Exception(script_resp)

    # update global vars for response
    variable_name = meta_data.get("output_variable_name")
    set_operation_output_variable(operation_index, variable_name, script_resp["value"])

    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    return script_resp["value"]


# main function to execute media injection
def inject_media(driver: WebDriver, operation_index: str) -> str:
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)

    # fetch media details
    media_info = operations_meta_data[operation_index].get('media_info')
    media_id = media_info.get('media_id')
    media_injection_type = media_info.get('media_injection_type')

    #determine lambda hook to execute based on media injection type
    lambda_hook = ""
    if media_injection_type == "image":
        lambda_hook = "lambda-image-injection"
    elif media_injection_type == "video":
        lambda_hook = "lambda-video-injection"

    # execute lambda hook
    print(f"Injecting media id: {media_id}")
    response = driver.execute_script(f"{lambda_hook}={media_id}")
    print(f"Successfully injected.")

    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    return response

#main function to handle deeplink

def execute_deeplink(driver: WebDriver, operation_index: str):
    """Executes the core deep link logic."""
    
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)
    
    meta = get_meta_data_value(operation_index)
    
    # Get raw values from metadata
    deep_link_url = meta.get('deep_link_url', '')
    package_name = meta.get('app_package_name', '')
    
    # Step 1: Resolve parameters first (${...})
    deep_link_url = get_parameter_value(deep_link_url, user_parameters) 
    package_name = get_parameter_value(package_name, user_parameters)
    deep_link_url = get_variable_value(deep_link_url, driver)
    package_name = get_variable_value(package_name, driver)
        
    
    automation_name = str(driver.capabilities.get('automationName', '')).lower()
    
    params = {"url": deep_link_url}

    # Set platform-specific identifier
    if automation_name == 'uiautomator2':
        params["package"] = package_name
    else:
        params["bundleId"] = package_name

    print(f"Executing deep link for URL: {deep_link_url} and package name: {package_name}")
    # Execute the deep link
    driver.execute_script("mobile: deepLink", params)
    print("Deep link executed successfully")

    # post process operation
    postprocess_operation(operation_index)
    
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)
    
    return {"success": True, "message": "Deep link executed successfully"}

# main ui action to handle interactions
def ui_action(driver: WebDriver, operation_index: str):
    global smart_variables_cache
    
    # execute test case start
    curr_test_case_name = get_test_case_name(operation_index, driver)
    lambda_test_case_start(driver, curr_test_case_name)
    
    custom_driver = CustomAppiumDriver(driver) # helper class to handle custom actions
    
    # additional wait time
    smart_wait(custom_driver, operation_index)

    attempts = 1
    max_retries = 2
    action = operations_meta_data[operation_index]['operation_type'].lower()
    
    for key, value in operations_meta_data[operation_index].items():
       if isinstance(value, str) and value.startswith("secrets."):
           env_var_name = value.split(".")[1]
           operations_meta_data[operation_index][key] = os.getenv(env_var_name, '')
    sub_instruction_obj = operations_meta_data[operation_index].get('sub_instruction_obj', {})
    failure_condition = operations_meta_data[operation_index].get('failure_condition', '')
    if isinstance(sub_instruction_obj, str):
        sub_instruction_obj = json.loads(sub_instruction_obj)

    if isinstance(sub_instruction_obj, dict):

        if 'params' in sub_instruction_obj:
            for key, value in sub_instruction_obj['params'].items():
                if not isinstance(value, str):
                    continue
                new_value = get_parameter_value(value, user_parameters)
                print(f"Resolved param value for key: {key} = {new_value} :: old value = {value}")
                if new_value != value:
                    get_meta_data_value(operation_index)[key] = new_value
                    if 'variable' in sub_instruction_obj and key in sub_instruction_obj['variable']:
                        sub_instruction_obj['variable'][key] = new_value

        if 'variable' in sub_instruction_obj:
            for key, value in sub_instruction_obj['variable'].items():
                new_value = get_variable_value(value, driver)
                print(f"Resolved variable value for key: {key} = {new_value} :: old value = {value}")
                if new_value != value:
                    if "scroll" in  action:
                        operations_meta_data[operation_index]["scroll_value"] = new_value
                    else:
                        operations_meta_data[operation_index][key] = new_value
                    
                    if 'operation_dict' in sub_instruction_obj and key in sub_instruction_obj['operation_dict']:
                        sub_instruction_obj['operation_dict'][key] = new_value
            operations_meta_data[operation_index]['sub_instruction_obj'] = json.dumps(sub_instruction_obj)

    # resolve operation if unresolved
    is_resolved = handle_unresolved_operations(operations_meta_data, operation_index, driver)
    
    locators = operations_meta_data[operation_index].get('locator', None)
    non_driver_operation = operations_meta_data[operation_index].get('non_driver_operation', False)
    is_coordinates_used_for_interaction = operations_meta_data[operation_index].get('is_coordinates_used_for_interaction', False)
    manual_interaction_tag = operations_meta_data[operation_index].get('manual_interaction_tag', '')
    element_coordinates_ratio = operations_meta_data[operation_index].get('element_coordinates_ratio', [])
    element_bounds_ratio = operations_meta_data[operation_index].get('element_bounds_ratio', [])
    element_coordinates = [0, 0]
    element_bounds = [0, 0, 0, 0]
    
    wait_for_element_timeout = int(operations_meta_data[operation_index].get('wait_for_element_timeout', 0))
    if wait_for_element_timeout == 0:
        wait_for_element_timeout = MAX_WAIT_UNTILTIME
        
    custom_driver.max_wait_until_time = wait_for_element_timeout

    # handle implicit wait
    implicit_wait = operations_meta_data[operation_index].get('implicit_wait', 10)
    driver.implicitly_wait(implicit_wait)

    while attempts <= max_retries + 1:
        try:
            
            # check if dismiss dialog required
            if operations_meta_data[operation_index].get('dismiss_dialog', False):
                custom_driver.perform_dismiss_dialog_action()
                break
            
            # determine element
            element = None

            # try xpath-based element lookup first (when not already using coordinates)
            if locators and not is_coordinates_used_for_interaction:
                findTime = time.time()
                element, locator_or_coords = find_element(driver, locators, operation_index, 2, 0)
                if element is None and isinstance(locator_or_coords, dict) and locator_or_coords.get('is_coordinates_used_for_interaction'):
                    # QWEN coordinate model won — switch to coordinate-based execution
                    is_coordinates_used_for_interaction = True
                    is_resolved = True  # coordinates from QWEN response, no need to recompute
                    element_coordinates_ratio = locator_or_coords.get('element_coordinates_ratio', [])
                    element_bounds_ratio = locator_or_coords.get('element_bounds_ratio', [])
                    print(f"Switched to coordinate-based interaction from healed xpaths, time taken: {time.time() - findTime} seconds")
                elif element is not None:
                    print(f"Element found in {time.time() - findTime} seconds")

            # resolve coordinates when using coordinate-based interaction
            if is_coordinates_used_for_interaction:
                # refresh coordinates ratio data if needed
                if not is_resolved:
                    element_coordinates_ratio, element_bounds_ratio = get_new_coordinates_ratio_for_operation(operation_index, driver)

                if isinstance(element_bounds_ratio, list) and len(element_bounds_ratio) == 4 and element_bounds_ratio != [0,0,0,0]:
                    x1, y1 = custom_driver.get_element_coordinates_from_ratio([element_bounds_ratio[0], element_bounds_ratio[1]])
                    x2, y2 = custom_driver.get_element_coordinates_from_ratio([element_bounds_ratio[2], element_bounds_ratio[3]])
                    element_bounds = [x1, y1, x2, y2]
                    element_coordinates = [(element_bounds[0] + element_bounds[2]) // 2, (element_bounds[1] + element_bounds[3]) // 2]

                else:
                    element_coordinates = custom_driver.get_element_coordinates_from_ratio(element_coordinates_ratio)

                print(f"Resolved element coordinates: {element_coordinates} :: bounds: {element_bounds}")
            
            # fetch element class
            element_class = custom_driver.get_element_class(element)
            
            # perform selector element actions
            if custom_driver.perform_selector_element_set_value_action(element, element_class, operations_meta_data[operation_index].get('value', operations_meta_data[operation_index].get('scroll_value', '')), action):
                pass

            elif 'click' in action:
                custom_driver.perform_click_action(element, element_class, is_coordinates_used_for_interaction, element_coordinates)
            
            elif action == 'type' or action == 'input' or action == 'search':                           
                input_text = operations_meta_data[operation_index]['value']
                multiple_inputs = operations_meta_data[operation_index].get('multiple_inputs', False)
                # Click to focus on element only if not already focused
                if not multiple_inputs:
                    if not manual_interaction_tag:
                        print(f"Clicking to focus on element for single input")
                        custom_driver.perform_click_action(element, element_class, is_coordinates_used_for_interaction, element_coordinates)
                else:
                    try:
                        if not custom_driver.is_keyboard_shown():
                            print(f"Keyboard not shown for multiple inputs, clicking to focus")
                            custom_driver.perform_click_action(element, element_class, is_coordinates_used_for_interaction, element_coordinates)
                    except:
                        pass
                
                if (not multiple_inputs and (not manual_interaction_tag or (custom_driver.is_ios() and element is not None))):
                    try:
                        print(f"Performing clear action before type")
                        custom_driver.perform_clear_action(element, is_coordinates_used_for_interaction)
                        
                        isKeyboardShown = custom_driver.is_keyboard_shown()
                        if not isKeyboardShown:
                            print(f"Keyboard not shown after clear, clicking again to focus")
                            custom_driver.perform_click_action(element, element_class, is_coordinates_used_for_interaction, element_coordinates)
                    except:
                        pass

                if action == 'search':
                    input_text = input_text + "\n"
                
                delay_ms = 0
                if multiple_inputs:
                    delay_ms = 1000 # 1 second delay for multiple inputs
                else:
                    # get type strategy ff
                    is_complete_text_type = get_feature_flags().is_text_typing_enabled(custom_driver.is_ios())
                    if not is_complete_text_type:  # char by char type check
                        delay_ms = 10
                
                sleepWaitTime = 0.1
                print(f"Waiting {sleepWaitTime} seconds before typing to ensure element is ready for typing")
                time.sleep(sleepWaitTime) # Add a delay to allow clear/click to complete
                custom_driver.perform_type_action(input_text, delay_ms, element, element_class)

            elif action == 'enter':
                custom_driver.perform_keyevent("ENTER")

            elif action == 'clear':
                if is_coordinates_used_for_interaction:
                    custom_driver.perform_click_action(element, element_class, is_coordinates_used_for_interaction, element_coordinates)
                    
                custom_driver.perform_clear_action(element, is_coordinates_used_for_interaction)

            elif action == 'refresh':
                driver.refresh()
            
            elif action.lower() == 'scroll_until_element':
                element_found = handle_scroll_until_element(custom_driver, operation_index)
                
                global IS_SCROLL_ELEMENT_FOUND
                IS_SCROLL_ELEMENT_FOUND = -1

                if not element_found:
                    raise ValueError("Element not found after scrolling")
                
            elif action.startswith('scroll'):
                # Retrieve scroll metadata
                direction = operations_meta_data[operation_index]['scroll_direction']
                scroll_value = int(operations_meta_data[operation_index]['scroll_value'])
                
                if not direction or not scroll_value:
                    raise ValueError("Missing required metadata: Scroll direction or value")
                
                # get screen bounds
                screen_bounds: List[int] = [0, 0, 0, 0]
                if action.startswith('scroll_element'):
                    if is_coordinates_used_for_interaction:
                        if element_bounds and element_bounds != [0, 0, 0, 0]: # use element bounds if available
                            screen_bounds = element_bounds
                        else:
                            screen_bounds = custom_driver.get_element_scroll_screen_bounds_from_coordinates(element_coordinates)
                    else:
                        screen_bounds = custom_driver.get_element_bounds(element)
                else:
                    screen_bounds = custom_driver.get_largest_scrollable_element_bounds()
                    
                # check if scroll value is in percentage
                is_percent_value = not action.endswith('pixels')
                mi_scroll_payload = operations_meta_data[operation_index].get('mi_scroll_payload', {})
                
                if mi_scroll_payload.get("is_accurate", False):
                    if "percentage" in action.lower():
                        for _ in range(0, scroll_value // 50):
                            _, scroll_cords = get_scroll_coordinates(screen_bounds, direction, 50, is_percent_value)
                            start_x, start_y, end_x, end_y = scroll_cords
                            custom_driver.perform_scroll_action(start_x, start_y, end_x, end_y, direction, duration=300, mi_scroll_payload=mi_scroll_payload)
                        scroll_value = scroll_value % 50
                        if scroll_value == 0:
                            break
                    elif "pixels" in action.lower() and custom_driver.automation_name.lower() == custom_driver.UiAutomator2:
                        device_info = driver.execute_script("mobile: deviceInfo")
                        density = device_info.get("displayDensity", 160)
                        scroll_value = int(scroll_value * density / 160)

                times_loop_range = 0
                if action.endswith('times'):
                    times_loop_range = scroll_value
                    scroll_value = 0 # use defaults
                    
                # perform scroll
                loop_range, scroll_cords = get_scroll_coordinates(screen_bounds, direction, scroll_value, is_percent_value)
                start_x, start_y, end_x, end_y = scroll_cords
                
                # check if times loop range is set
                if times_loop_range:
                    loop_range = times_loop_range
                
                if mi_scroll_payload.get("startX") is not None:
                    custom_driver.perform_scroll_action(start_x, start_y, end_x, end_y, direction, duration=300, mi_scroll_payload = mi_scroll_payload)
                else:
                    for _ in range(loop_range):
                        custom_driver.perform_scroll_action(start_x, start_y, end_x, end_y, direction, duration=300, mi_scroll_payload = mi_scroll_payload)

            elif action == 'wait':
                # get wait duration from sub instruction object
                if isinstance(sub_instruction_obj, str):
                    sub_instruction_obj = json.loads(sub_instruction_obj)
                if not isinstance(sub_instruction_obj, dict):
                    raise ValueError("Invalid sub instruction object for wait action")
                curr_operation_dict :dict = sub_instruction_obj.get("operation_dict", {})
                wait_duration = get_meta_data_value(operation_index).get("duration", None)
                if wait_duration is None:
                    wait_duration = curr_operation_dict.get("duration")
                if wait_duration is None:
                    raise ValueError("Wait duration not specified")
                
                if not isinstance(wait_duration, str):
                    wait_duration = str(wait_duration)
                wait_duration = get_variable_value(wait_duration, driver, get_all_runtime_variables())
                if wait_duration is None or wait_duration == "":
                    raise ValueError("Wait duration not specified")
                
                if isinstance(wait_duration, (int, float)):
                    wait_duration = float(wait_duration)
                else:
                    wait_duration = float(str(wait_duration).strip())
                    
                if wait_duration < 0:
                    raise ValueError(f"Wait duration cannot be negative: {wait_duration}")
                print(f"Waiting for duration: {wait_duration} seconds")
                time.sleep(wait_duration)
                
            elif action == 'navigate':
                direction = operations_meta_data[operation_index]['navigation_direction']
                custom_driver.navigate(direction)
                
            elif action == 'open_app' or action == 'switch_app':
                app_info = json.loads(operations_meta_data[operation_index].get('value', '{}'))
                package_name = app_info.get('package_name', app_info.get("packageName", ""))
                if not package_name:
                    raise ValueError("Package name not found")

                custom_driver.activate_app_with_fallback(package_name)

            elif action == 'close_app':
                current_package = custom_driver.get_current_package()
                if custom_driver.is_system_popup_package(current_package):
                    custom_driver.perform_dismiss_dialog_action()
                    current_package = custom_driver.get_current_package()
                    
                app_info = json.loads(operations_meta_data[operation_index].get('value', ''))
                package_name = app_info.get('package_name', app_info.get("packageName", ""))
                if not package_name:
                    package_name = current_package
                    
                custom_driver.perform_terminate_app_action(package_name=package_name, kill_timeout_ms=3000, max_attempts=2)


            elif action == 'orientation':
                setattr(driver, 'orientation', operations_meta_data[operation_index]['value'])
                
            elif action == 'keyboard':
                value = operations_meta_data[operation_index].get('value', 'hide')
                custom_driver.perform_keyboard_action(value)

            elif action == 'notification':
                value = operations_meta_data[operation_index].get('value', '').lower()
                if value == 'show':
                    custom_driver.open_notifications()
                elif value == 'hide':
                    custom_driver.hide_notifications()
                    
            elif action == 'keyevent':
                value = operations_meta_data[operation_index].get('value', '')
                if manual_interaction_tag:
                    value = int(value)
                    custom_driver.perform_keyevent('', value)
                else:
                    custom_driver.perform_keyevent(value)
                        
            elif action == 'background':
                current_package = custom_driver.get_current_package()
                if custom_driver.is_system_popup_package(current_package):
                    custom_driver.perform_dismiss_dialog_action()
                
                # get background duration from sub instruction object
                if isinstance(sub_instruction_obj, str):
                    sub_instruction_obj = json.loads(sub_instruction_obj)
                if not isinstance(sub_instruction_obj, dict):
                    raise ValueError("Invalid sub instruction object for Background action")
                curr_operation_dict :dict = sub_instruction_obj.get("operation_dict", {})
                bg_duration = get_meta_data_value(operation_index).get("duration", None)
                if bg_duration is None:
                    bg_duration = curr_operation_dict.get("duration")
                if bg_duration is None:
                    raise ValueError("Background duration not specified")
                
                if not isinstance(bg_duration, str):
                    bg_duration = str(bg_duration)
                bg_duration = get_variable_value(bg_duration, driver, get_all_runtime_variables())
                if bg_duration is None or bg_duration == "":
                    raise ValueError("Background duration not specified")
                
                if isinstance(bg_duration, (int, float)):
                    bg_duration = int(bg_duration)
                else:
                    bg_duration = int(float(str(bg_duration).strip()))
                    
                if bg_duration < 0:
                    raise ValueError(f"Background duration cannot be negative: {bg_duration}")
                print(f"Sending app to background for duration: {bg_duration} seconds")
                custom_driver.send_app_to_background(bg_duration)

            elif action.lower() == "mathematical_operation":
                output_var = operations_meta_data[operation_index].get("math_result_variable_name")
                if non_driver_operation:
                    print("computing mathematical operation")
                    math_result_variable_name, _ = Mathmatic.from_json(operations_meta_data[operation_index].get("expression_tree", {})).evaluate(user_variables, get_variable_value)
                    set_operation_output_variable(operation_index, output_var, math_result_variable_name)
                    
                    # post process operation
                    postprocess_operation(operation_index)
                    
                    # execute test case end lambda hook
                    lambda_test_case_end(driver, curr_test_case_name)
                    
                    return math_result_variable_name
                else:
                    expression_tree = operations_meta_data[operation_index]['expression_tree']
                    math_result = eval_math(expression_tree, driver)
                    set_operation_output_variable(operation_index, output_var, math_result_variable_name)
                    
                    # post process operation
                    postprocess_operation(operation_index)
                    
                    # execute test case end lambda hook
                    lambda_test_case_end(driver, curr_test_case_name)
                    return math_result

            elif action.lower() == "assertion":
                if non_driver_operation:
                    assertion_value, _ = Assertion.from_json(operations_meta_data[operation_index].get("expression_tree", {})).evaluate(user_variables, get_variable_value)
                else:
                    assertion_tree = operations_meta_data[operation_index]['assertion_tree']
                    assertion_value = evaluate_assertion(assertion_tree, driver)
                print(f"Assertion result: {assertion_value}")
                if not assertion_value:
                    print(f"Checking Failure condition: {failure_condition}")
                    if failure_condition == FailureCondition.FAIL_TEST_IMMEDIATELY.value or failure_condition == FailureCondition.NONE.value:
                        set_test_status("failed")
                        raise RuntimeError(f"Assertion failed, exit..")
                    elif failure_condition == FailureCondition.FAIL_BUT_CONTINUE_EXECUTING.value:
                        print(f"Assertion failed but continue executing..")
                        set_test_status("failed")
                    elif failure_condition == FailureCondition.WARN_BUT_CONTINUE_EXECUTING.value:
                        print(f"Warning!! Assertion failed..")
                        
                # post process operation
                postprocess_operation(operation_index)
                
                # execute test case end lambda hook
                lambda_test_case_end(driver, curr_test_case_name)
                return assertion_value
            
            elif action.lower() == "textual_query":
                if operations_meta_data[operation_index]['use_query_v2']:
                    if operations_meta_data[operation_index]['query_info_dict']['custom_data_hook_name']:
                        custom_hook_dict = get_attribute(element, driver, "custom_attributes_dict")
                        result = custom_hook_dict.get(operations_meta_data[operation_index]['query_info_dict']['custom_data_hook_name'], "")
                    else:
                        result = get_attribute(element, driver, operations_meta_data[operation_index]['query_info_dict']['selected_attribute_name'])
                        regex = operations_meta_data[operation_index]['query_info_dict'].get('regex', None)
                        if regex:
                            regex = base64.b64decode(regex).decode("utf-8")
                            result = re.search(fr"{regex}", result)
                            if result:
                                result = result.group(1)
                            else:
                                result = None
                    
                    if result and result != "":
                        set_query_operation_output_variable(operation_index=operation_index, var_value=result)
                        # post process operation
                        postprocess_operation(operation_index)
                        
                        # execute test case end lambda hook
                        lambda_test_case_end(driver, curr_test_case_name)
                        return result
                    else:
                        return vision_query(driver, operation_index)
                else:
                    return vision_query(driver, operation_index)
                
            elif action.lower() == 'set_variable':
                # get var name from sub instruction object
                if isinstance(sub_instruction_obj, str):
                    sub_instruction_obj = json.loads(sub_instruction_obj)
                if not isinstance(sub_instruction_obj, dict):
                    raise ValueError("Invalid sub instruction object for set_variable action")
                curr_operation_dict :dict = sub_instruction_obj.get("operation_dict", {})
                variable_name = curr_operation_dict.get("variable_name")
                variable_value = get_meta_data_value(operation_index).get("variable_value", None)
                if variable_value is None:
                    variable_value = curr_operation_dict.get("variable_value", "")
                variable_value = get_variable_value(variable_value, driver, get_all_runtime_variables())
                set_operation_output_variable(operation_index, variable_name, variable_value)
                
                # execute test case end lambda hook
                lambda_test_case_end(driver, curr_test_case_name)
                return variable_value
            
                    
            elif action == 'network_throttle':
                network_throttle_payload = operations_meta_data[operation_index].get('network_throttle',{})

                if not network_throttle_payload:
                    raise ValueError("Network throttle payload is missing")
                
                is_mobile_offline = operations_meta_data[operation_index].get('is_mobile_offline', False)

                execute_network_throttle(driver, is_mobile_offline = is_mobile_offline, network_throttle = network_throttle_payload)

            elif action == "db_query":
                response = DbQuery(operation_index = operation_index).db_query()
                if "error" in response:
                    raise RuntimeError(f"Error in DB query: {response['error']}")
                set_operation_output_user_variable(operation_index=operation_index, var_value=response)

            elif action.lower() == "generative":
                flow = GenerativeFlow(
                    server_url=os.environ.get('AUTOMIND_URL', 'https://kaneai-api.lambdatest.com'), 
                    username=os.environ.get('LT_USERNAME', ''),
                    accesskey=os.environ.get('LT_ACCESS_KEY', ''),
                    driver=driver, 
                    request_id=operations_meta_data[operation_index].get('instruction_id'),
                    platform="mobile",
                )
                flow.set_ui_action_executor(ui_action)
                flow.set_operations_meta_data_executor(override_operations_meta_data)
                try:
                    # Run the complete automation loop
                    outcome = sub_instruction_obj.get("outcome", "")
                    asyncio.run(flow.run_automation_loop(
                        objective=operations_meta_data[operation_index].get('operation_intent'),
                        expected_output=outcome,
                    ))
                except Exception as e:
                    raise e
                finally:
                    asyncio.run(flow.cleanup())
                    reload_metadata_root(current_active_root)
                
            elif action.lower() == "accessibility":
                custom_driver.execute_accessibility_scan()

            else:
                raise ValueError("Invalid action: {}".format(action))
            
            break
            
        except Exception as e:
            attempts += 1
            is_optional = operations_meta_data[operation_index].get('optional_flag', False)
            if action.lower() == "assertion":
                raise e
                
                
            # handle max retry cases
            if attempts > max_retries:
                if failure_condition == FailureCondition.FAIL_BUT_CONTINUE_EXECUTING.value:
                    print(f"Failed to execute action: {action} on locator: {operations_meta_data[operation_index].get('locator', '')}. Error: {e} :: Traceback: {traceback.format_exc()}")
                    set_test_status("failed")
                    break
                elif failure_condition == FailureCondition.WARN_BUT_CONTINUE_EXECUTING.value:
                    print(f"Failed to execute action: {action} on locator: {operations_meta_data[operation_index].get('locator', '')}. Error: {e} :: Traceback: {traceback.format_exc()}")
                    break

                if not is_optional:
                    raise RuntimeError(f"Failed to execute action: {action} on locator: {operations_meta_data[operation_index].get('locator', '')}. Error: {e} :: Traceback: {traceback.format_exc()}")
                else:
                    print(f"Failed to execute action: {action} on locator: {operations_meta_data[operation_index].get('locator', '')}. Error: {e} :: Traceback: {traceback.format_exc()}")
                break
            else:
                # wait for retry delay
                retry_delay = operations_meta_data[operation_index].get('retries_delay', 1)
                if not retry_delay:
                    retry_delay = 1
                time.sleep(retry_delay)
        finally:
            smart_variables_cache = None
            
    # post process operation
    postprocess_operation(operation_index)
                
    # execute test case end lambda hook
    lambda_test_case_end(driver, curr_test_case_name)

#############################################################################################################